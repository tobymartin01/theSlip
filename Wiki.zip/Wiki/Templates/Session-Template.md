---
type: session
world: Vardin
campaign: The Slip
location: 
characters: 
tags: 
previous_session: 
date: ""
banner: https://i.ytimg.com/vi/xPlh0UStB78/maxresdefault.jpg
banner-fade: -160
---

# Title
