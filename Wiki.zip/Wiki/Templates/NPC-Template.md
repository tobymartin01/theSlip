---
type: NPC
faction: 
location: 
world: Vardin
campaign: The Slip
description: 
race: 
gender: 
class:
---
