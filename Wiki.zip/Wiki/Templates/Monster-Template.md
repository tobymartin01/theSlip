---
type: Monster
world: Vardin
campaign: The Slip
description: 
race: 
size: 
threat: []
---
