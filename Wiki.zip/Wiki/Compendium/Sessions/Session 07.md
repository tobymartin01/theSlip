---
type: session
world: Vardin
campaign: The Slip
location: Arcabourne
characters:
tags:
  - session
previous_session: "[[Session 06]]"
date: 2025-08-06
banner: https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fimages.nightcafe.studio%2Fjobs%2FHmtVK1Aq6LTobSCM9vUM%2FHmtVK1Aq6LTobSCM9vUM--1--lfaqs.jpg%3Ftr%3Dw-1600%2Cc-at_max&f=1&nofb=1&ipt=801e91999ec07132638d92c8c0f4e175aa7d7e213c06c68499632df16519db4c
banner-fade: -160
---

# [[Argyle Guild Hall]]

- The morning after our abrupt induction into [[The Argyles]], we find ourselves gathered in the echoing mess hall of the Guild. The scent of fresh bread and something vaguely burnt hangs in the air.
- We've been assigned to _Argyle Team Omega_, a black-ops designation that, while functional, lacks flair. Over breakfast,steaming porridge and slightly stale biscuits,we decide we need a public-facing name, something with style. After some spirited debate, we christen ourselves: **Scrolls and Trolls**.
- Conversation drifts naturally to our backstories,how each of us came to this moment, this guild, this table. There's laughter, some solemn silence, and the occasional raised eyebrow.
- After breakfast, we head to the showers. Cold water. No privacy. The Guild doesn’t waste luxuries on the expendable.
- Feeling marginally more awake, we approach the **Guild Notice Board**,a towering wall of chaos. As a grung, I'm utterly dwarfed by its size. Notices upon notices are plastered in wild, overlapping layers. The wooden backboard is barely visible beneath the paper deluge.
- The sheer volume of unchecked jobs speaks to a grim reality: The Argyles are massively understaffed.
- As I climb a stool to get a better view, a rough voice sounds behind us, another guild member mutters:

>	_"Everything flows through the board, it's the heart of the guild"_

- The important contracts are sealed with different coloured waxes, each bearing noble crests. These are the real money-makers: **dangerous but lucrative** jobs sanctioned by the city's elite.
- Below them, a chaotic layer of _dirty jobs_, minor, low-risk tasks with modest rewards. They're numerous and disorganised, scraps barely clinging to the board with tattered edges and smudged ink.
- At the very bottom are the **beggars’ requests**, offering no pay at all. Just pleas for help.
- One warning catches our attention: 

>	_"Don't touch the ones with black string... if you value your life."_ 

- Noted.
- On impulse, we pull a mid-tier contract, its wax seal chipped but still intact. A **wealthy industrialist** has gone missing. His son is seeking help after the city guard’s investigation turned up little. Last known direction? The **city sewers**.
- We regroup to discuss. Despite the risks, we agree to take it.
- Head over to the Guild's admin desk. A rough-looking man,scarred and missing his left arm at the elbow, greets us without warmth. This is [[David]], the guild administrator.
- He checks the contract and gestures us forward. The job pays **5 gold if the father is confirmed dead, 10 if alive**.
- From a nearby locked chest, he produces a strange weapon,a **synthesis crossbow**, a hybrid between a lever-action rifle and a crossbow. Sleek, deadly, and loaded with **five light-blue crystalline bolts**.
- [[Desmond]] steps forward and takes the weapon with a respectful nod.
- With the contract in hand and gear ready, we leave the Guild and head into the city to track down our client.
- As a former merchant, I recognise the name: the **Vayron family**. Powerful. Wealthy. Based in the **industrial district**.
# [[Arcabourne]]
- The early morning streets of [[Arcabourne]] are already alive with activity. Smog curls between brick chimneys and the scent of burning coal hangs heavy.
- We navigate through cobbled streets to the Vayron estate, a lavish manor nestled within wrought-iron gates and flanked by stone dragons.
- A butler greets us with practiced politeness. We explain our business and our connection to the Guild. We're ushered inside.
- The halls of the manor are opulent paintings in gilded frames, plush carpets underfoot, gold filigree on the moulding. It reeks of old money.
- We’re guided into a massive breakfast room, large enough to rival the Guild’s mess hall.
- At the centre of a long, ornate table sits **Young Master Vayron**. He is pristine, immaculately dressed and wearing a perpetual expression of entitled disinterest.
- He confirms that the contract has been sitting on the Guild board for several days with no takers. His father's disappearance is no longer just a personal matter, it’s becoming a political liability.
- The elder Vayron was last seen returning from a business meeting along a familiar route. His carriage was found abandoned, the **driver later discovered dead** in an alley. No sign of the father.
- The young master is not concerned with our methods. He only wants **confirmation of his father’s fate**, a body or a **family ring** will suffice.
- Under the pretence of looking for a restroom, I split off and subtly scan the building. It's clear this family values secrecy. The heir seemed... slightly too calm.
- We head toward the sewers, as directed by the initial investigation.

# **City Sewers**
- The sewer entrance is sealed with iron grating and official warnings,_Disease, Rats, Trespassers Will Be Prosecuted_. A hidden lever nearby disengages the lock.
- As the gate groans open, a **beggar shuffles out from the shadows** of a nearby alley. Ragged clothes, a limp, eyes like chipped glass.
- I flick **2 copper** in his direction and ask if he’s seen anything.

    > _"Two men in masks stopped the merchant’s carriage. Dragged 'im out... stabbed the driver right there. Hauled the big man into the sewer... never came back."_

>[!example] Interaction
-2 copper 

- Just inside the entrance, **scuff marks and blood** confirm his tale.
- With a shared glance, we light torches and descend the iron ladder into the gloom.
- The deeper we go, the more distant the world above becomes,sunlight filters through grates like dying stars, and the city's morning noise fades to nothing but **drips and echoes**.
- The tunnel eventually opens into a **wide chamber** slick with damp. In one corner lies a body, splayed in a pool of blood.
- I step forward to investigate.
    

> [!tip] Encounter  
> Initiative: 19  
> 12 damage taken  
> All 3 enemies defeated; combat ends.

- The sudden ambush of [[Hollow]] catches us off-guard, but we survive the encounter. The last foe falls, and once again the silence returns, broken only by the faint drip of sewage.
- I approach the body. It's undeniably **the elder Vayron**, his **ornate robes torn**, **flesh chewed and clawed**, and **eyes long since dimmed**.
- The **family ring** is missing from his finger, but a glint of gold catches my eye nearby. **Spat out by something**, it lies slick in a pool of **dweller saliva**.
- I retrieve the ring. A **coiled dragon around a hammer**, the Vayron crest.
- [[Desmond]] hands it to me with a grim look. The mission is complete… at least, on paper.
- We begin our return to the manor, but suspicions weigh heavy.
- There’s something not right. The **young heir’s cold demeanour**, the **delay in reporting**, the **ease with which the father was taken**,it all stinks worse than the sewers.
- We discuss our next steps. Do we hand over the ring… or do we break into the manor and **search for real answers**?
- Did the **young master arrange this**, or was it a **rival family’s move** in a deeper game?






