---
type: session
world: Vardin
campaign: The Slip
game_date: 
location: Arcabourne
characters:
  - Obu
  - Lyra
  - Tibber
  - PS
tags: 
previous_session: "[[Session 3]]"
date: 2025-06-22
banner: https://i.ytimg.com/vi/xPlh0UStB78/maxresdefault.jpg
banner-fade: -160
---

# Dungeon under Archeology Guild
- Lyra and Rock man begin to leave with the nmenoscope
- Come across Obu and Piss Sorcerer being held hostage
- fight against rogue

>[!tip] Encounter
Initiative 17
>1x  Rogue
>Rogue defeated and Battle ended

- Obu head over to check the rogues corpse

>[!example] Interaction
+1 Florian Broach
+1 Poison Vial (2x uses)
+1 Paper with broken purple seal (the language is unknown to me)

- Group up to leave dungeon
- Large [[Sentinel]]wakes up

>[!tip] Encounter
Initiative 18
>1x  Large Automaton
>4 dmg received (14 hp)
>Automaton defeated and Battle ended

- Rock man checks out the front entrance and says it looks clear
- we head out
- immediately surrounded by city guard
- we lose our belongings, including the nmenonscope, and are taken to jail