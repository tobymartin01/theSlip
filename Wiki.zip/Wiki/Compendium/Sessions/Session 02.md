---
banner: "[[marked_world_map.png]]"
type: session
location: Arcabourne
world: Vardin
date: 2025-05-08
previous_session: "[[Session 01]]"
tags:
  - session
---


# Wakey Wakey - [[Arcabourne]] Inn
- Wake up in the group room rented for the night
- meet [[Tibber]], we bring him to the party. Has a pet rock known as [[Greg]]. Half orc. slightly crazy
- head out looking for [[Darwin]] who promised information in the black market.
- [[Vailenn]] offers 25% as promise for the information and will pay the remainder after the act has been carried out
- ![[heist_information.webp]]
- Head back to tavern to discuss and plan
- Need to pay a visit to [[Tellen]] who can hopefully provide some useful information on a secret entrance
- Hand over 50 silver for the mint wine

>[!example] Interaction
-1 gold piece
+100 Silver Pieces
-50 silver piecess

- Travel to visit [[Tellen]] at the admin building
- talk to wrong person, wine bottle is empty?
- break wrong door down
- finally find right room, enter to find [[Tellen]]
- "bargain" to get the activation sigil of [[Tellen]] for 5 gold.
- Wait for dusk to enter secret entrance
- purchase food and drink to wait

>[!example] Interaction
-2 copper

- find secret entrance
- enter using override sigil
- pass through a long tunnel
- find a boarded up entrance, removed a board and entered the room
- scaffolding to get down.
- Scaffold breaks, fail stealth


>[!tip] Encounter
Initiative 22
>4x Automaton [[sentinel]]s
>3 dmg received
>Battle ended



