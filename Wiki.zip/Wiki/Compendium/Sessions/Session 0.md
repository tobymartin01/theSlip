---
type: session
world: Vardin
date: 2025-04-02
location: Vardin
---

- Discussed character creation, world backstory, how d&d works 
- 7 players in total
- using owlbear rodeo instead of tabletop
- character sheet created and modified on dungeon master's vault