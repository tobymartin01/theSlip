---
type: session
world: Vardin
campaign: The Slip
location: Arcabourne
characters:
  - Lyra
  - Mechamaru
  - Mini
  - Obu
  - Desmond
  - Tibber
tags:
  - session
previous_session: "[[Session 09]]"
date: 2025-09-10
banner: https://i.ytimg.com/vi/xPlh0UStB78/maxresdefault.jpg
banner-fade: -160
---

# The Nest
- Still inside of the ruined bathhouse tackling the creatures within
> [!tip] Encounter  
    > - Initiative: 15
> - [[Obu]] and [[Mechamaru]] enter a small room to the left where [[Obu]] encounters a new enemy lurking in the shadows and engages, landing the initial couple of attacks successfully with precise strikes
> - Enemy retaliates with a sudden counterattack, its claws cutting deep into [[Obu]]
> - **take 5 dmg**
>- The fight continues with a quick exchange of blows; [[Obu]] manages to keep the upper hand, delivering decisive finishing strikes
>- Both enemies in the side room fall, their bodies collapsing into the ruined debris
>- The room is searched; the boxes and crates within contain nothing useful, just rotted and ruined food supplies long past any use
>- [[Mechamaru]] moves to [[Obu]]’s side and channels healing energy through Healing Hands
>- _Heal 10 points_
>- Pressing deeper, the pair come across a pit in the darkness, the ground around it slick with slime — it looks to be a **[[Spawning Pit]]**, a grotesque breeding ground pulsing faintly with unnatural energy
>- Choosing not to linger, they walk past the pit and encounter a new foe: a hunched, more corrupted creature, twice the size of the ones previously fought. Its presence dominates the room, its body pulsating and bulging unnaturally
>- With a guttural roar, the creature swings violently at [[Obu]]
>- **take 12 dmg**
>- The creature follows up with another swing, releasing a wave of corrupting energy across the chamber. [[Obu]] steels his body and withstands it, but another brutal physical strike lands
>- **take 5 dmg**
>- [[Mechamaru]] quickly utters a Healing Word to keep [[Obu]] on his feet
>- _Heal 7 hp_
>- A flurry of blows follows; [[Obu]] darts in with speed and cunning, weaving between attacks and striking vital points
>- Using the environment to his advantage, [[Obu]] executes a sneaky maneuver and manages to shove the hulking entity backwards, toppling it into the **[[Spawning Pit]]** in front of [[Mechamaru]]
>- The slime within the pit reacts instantly, gripping the large creature and dragging it down, preventing it from crawling back out
>- Seizing the moment, [[Mechamaru]] hurls the **[[Phosphor tube purifiers]]** into the pit, their chemical light igniting the slime in a searing blaze
>- The pit erupts in fire and acrid smoke; the monstrous creature thrashes violently before being consumed, its roar cut short as the flames burn everything in sight
>- The **[[Spawning Pit]]** collapses in on itself, the walls around the chamber writhing and shriveling like dying flesh
>- The dense mist that had suffocated the area begins to thin, then slowly dissipates - vision clears, the oppressive atmosphere lifts, and the group can finally see normally again
>- [[Obu]], battered but determined, hears the distant clash of steel and cries of combat. Without hesitation, he rushes toward the sound to assist the rest of the party
>- [[Mechamaru]], after a quick search of the room, follows closely ready to lend healing and support
>- Arriving just in time, they join forces with their allies; the tide turns quickly
>- All enemies are defeated, the corrupted forces scattered, and the chamber finally falls into silence

- While retracing our steps back to the entrance, following a job well done, we come across a small figure hunched near the wall - it is the stone gnome, one of our companions who had split from the group earlier
- At first there is a flicker of recognition, but as the gnome looks up we see his face in the dim light. His veins glow faintly purple, branching unnaturally beneath the skin, and his flesh has begun to twist and mutate
- The corruption has claimed him entirely. His eyes are vacant, filled only with malice and hunger. He is no longer our friend
- The stench of decay rolls from him, mixed with a strange chemical musk - the same corruption that poured from the spawning pit
- His body jerks unnaturally as he rises to his feet, movements disjointed like a puppet pulled on rotting strings
- There is no chance for words or reasoning. The gnome’s form is too far gone. The corruption has stripped away his will, leaving only a vessel of disease and rage
- A heavy silence falls between the party as they realize what must be done. There is no saving him now. He must be purified
- The corrupted gnome lets out a warped scream, half pain, half fury, and charges forward, jagged claws sprouting where hands once were
- [[Obu]], [[Tibber]] and [[Lyra]] brace for the clash, heart heavy but resolve unshaken - this fight is not for victory alone, but for mercy
- [[Mechamaru]] and [[Desmond]] ready their magic, eyes fixed on their former ally with sorrow and determination. Together, they prepare to end the suffering of one who can never return
- ![[Corrupted_Stone_Gnome.webp]]

> [!tip] Encounter  
    > - Initiative: 1
>- The corrupted gnome lets out a guttural screech, slipping swiftly to the edge of the group. With unnatural speed, he swings in a wide arc, his corrupted claws tearing through the air and striking both [[Mechamaru]] and [[Tibber]]
>- The gnome’s scream echoes through the chamber, summoning reinforcements. From the shadows, two twisted entities crawl forward, emerging behind [[Obu]] and [[Lyra]], effectively trapping the party between the gnome in front and the summoned horrors at their back
>- [[Obu]] whirls around and strikes one of the shadow-spawned entities, landing a solid blow to its warped form. His poisonous skin, usually a weapon in its own right, seems to have no effect on these creatures — they are beyond natural toxins
>- [[Obu]] presses the attack with precision, eliminating one of the entities with a decisive strike, its body collapsing into black ichor before dissolving into mist
>- The second entity lashes out in retaliation, its claw cutting through [[Obu]]’s defenses
>- **take 3 dmg**
>- Refusing to yield ground, [[Obu]] counters immediately, landing a strong retaliatory blow that staggers the creature
>- Meanwhile, the corrupted gnome attempts to slink away into the darkness, trying to escape the melee. The party, alert to his movement, intercepts him — several quick strikes land while he tries to break free, leaving him reeling under the assault
>- [[Obu]] closes the gap and unleashes a Flurry of Blows on the gnome, his first strike hitting with force, though the follow-up two swings miss as the gnome twists unnaturally out of reach
>- With the last of their strength, the party eliminates the remaining entity. [[Lyra]], who had fallen unconscious from the fight, is dragged back from the brink and stabilized before her condition worsens
>- The corrupted gnome snarls and, with veins pulsing violently, unleashes his wide-cast corruption spell once more. A wave of energy bursts out in all directions
>- Both [[Obu]] and [[Lyra]] fail to dodge the blast, their bodies wracked with searing pain
>- **take 16 dmg**
>- The battlefield is chaos — two allies unconscious, the rest battered and drained. Recognizing the danger of annihilation, the party makes the hard choice to retreat
>- They break away from the corrupted gnome, dragging their fallen with them. The chamber echoes with the gnome’s maddened screeches as the party escapes into the dark corridors, bloodied but alive
