---
type: session
world: Vardin
campaign: The Slip
location: Arcabourne
characters:
  - Mechamaru
  - Mini
  - Obu
  - Tibber
tags:
  - session
previous_session: "[[Session 08]]"
date: 2025-09-03
banner: https://creator.nightcafe.studio/jobs/eYFoEr5J1HzNNnYpbEvO/eYFoEr5J1HzNNnYpbEvO--2--d19s6.jpg
banner-fade: -160
---
# [[Argyle Guild Hall]]

- After handing the young noble into authorities we received 5 gold as a party. The guild clerk seemed unimpressed with the noble’s protests, scribbling his name down into a ledger before escorting him away.

> [!example] Interaction  
+1 Gold

- It is a new day. The hall is noisy with the chatter of adventurers and the clatter of cutlery. The smell of fresh bread and salted meats fills the air as we gather at a long wooden table.
- As we eat our breakfast, a steward strolls up, a young man in crisp livery, bowing slightly before saying that [[Caroline]] requests our presence. His tone is polite, but with a hint of urgency.
- We finish our breakfast and head up the creaking stairs to [[Caroline]]’s main office. The door is half-open, papers scattered in chaotic stacks, maps pinned at odd angles on the wall. She looks up, dark circles under her eyes, quill still in hand.
- We outline how we made easy work of the previous mission, explaining the missing merchant case and how we resolved it. She nods curtly, clearly already aware. Word travels fast in the guild.
- Caroline leans back in her chair and lowers her voice: word has reached the guild of a possible _nest_ down in the old quarter, in a ruined bath house. The description alone makes her uneasy.
- She explains: “Some may already be corrupted. Cleanse the area. No survivors… no witnesses. If they’re taken by it, there’s no coming back.”
- Caroline stresses the gravity of the task: _the corrupted cannot be cured_. It is only a matter of time before they turn fully. Mercy here is cruelty.
- From under her desk she carefully produces two metal tubes, capped with iron ends. Inside sloshes a shimmering golden liquid, glowing faintly even in the daylight. A thin wire trigger runs across each cap. “Phosphor tube purifiers,” she explains. “They’ll burn away anything within ten feet. Incredibly fragile. Incredibly dangerous. And incredibly expensive.”
- [[Mechamaru]] and [[Desmond]] each take one of the explosives, handling them with extreme care. The faint warmth can be felt even through the metal.

> [!example] Interaction  
+2 [[Phosphor tube purifiers]]

- We leave the office, [[Caroline]] is already waving over another adventurer for a briefing and make our way down to the quartermaster [[David]]. His shop smells of oiled leather and iron, weapons and tools neatly displayed behind a barred counter.
- After some haggling and browsing, [[Obu]] orders a pair of pig iron knuckle dusters. David warns that forging a good set will take time. “Come back next time and I’ll have them ready,” he says.
- He names the price for an even better pair: 16 gold. Pricey, but worth the quality. [[Obu]] pays the 2 gold for the pig iron pair.

> [!example] Interaction  
 -2 gold

- Exiting the headquarters into the bustling city streets, we notice the sharp contrast between the central districts and the old quarter. Here, life is vibrant: merchants shout, carts rattle by, children dart through crowds.
- As we walk toward the old quarter, the quality of the city drops quickly. Stone turns to mud, the air grows heavy with smoke and rot, and the sound of laughter is replaced with silence and whispers.
- Dirt, grime, and the smell of sewage cling to every corner. Rotting houses lean precariously into narrow alleys, many collapsed entirely. The neglect of this place is plain to see.
- As we near the destination, the air shifts. It feels thinner, as though climbing to a mountain’s peak. Each breath becomes heavier, laboured. A faint buzzing echoes in our ears.
- The ruined bathhouse looms ahead: cracked marble pillars, black mould crawling across walls, the once-grand structure now barely standing. The fog gathers thickly around the entrance.

---

# **The Nest**

- We step inside, and our vision immediately shrinks. The fog is suffocating, pressing in from every angle. The air tastes stale, metallic, and every sound is muffled.
- Shadows twist at the edge of our sight, forcing us to strain to see more than a few feet ahead.
- A figure slouched against a table comes into view - still, unmoving. Its posture is unnatural.
****
> [!tip] Encounter  
    > Initiative: 15
    > 
    > - A firebolt streaks through the haze, striking the slouched figure. It jerks violently awake, revealing its once-human form, now warped and distorted. Flesh bubbled, eyes cloudy, its mouth opens in a rasping hiss.
    >     
    > - Another creature stirs from the darkness, claws scraping across the floor. Then another. The nest is not empty.
    >     
    > - In the confusion, one creature lunges — but a quick strike finds its mark. A punch lands with bone-cracking force, and the creature’s head bursts apart, scattering ichor into the fog.
    >     
    > - Pressing forward, another creature blocks the hallway. After a vicious exchange, it is brought down with coordinated blows.
    >     
    > - In the chaos, one of us stumbles into a stagnant pool of dark water. The filth clings to skin and clothes, stinking of rot. Something moves beneath the surface.
    >     
    > - Deeper in, [[Mechamaru]] and [[Obu]] face down a more twisted entity, fighting in near silence. Obu lands the final, decisive blow, the creature collapsing into the murk.
    >     
    > - **(4 dmg taken)** in the struggle, bruises and shallow cuts marking the fight.
    >     
    > - Another corrupted stumbles from a side chamber. Together with [[Mechamaru]], we dispatch it swiftly before pushing deeper into the ruin.
    >     
    > - The fog grows thicker the deeper we move. Something more lies within…
    >     
    > - continue next session…
    
    