---
date: 2025-07-09
type: session
previous_session: "[[Session 4]]"
banner: https://www.dndspeak.com/wp-content/uploads/2021/04/Prisoner-1.jpg
banner-fade: -265
banner-radius: 28
characters:
  - Lyra
  - Obu
  - Tibber
  - Mechamaru
location: Arcabourne
---
# Prison
- We awake groggily in our cells.  
- The air is damp and cold. Each of us is alone in a dark, soulless stone cell, runes dimly glowing on the doors and bars.  
- [[Obu]] attempts to squeeze through the bars, but upon touching them is violently shocked - bright blue runes flare to life with a hum of magical energy.  

>[!example] Interaction
Take 5 damage

- Before long, the silence breaks as a stream of guards arrives. We are shackled and escorted, one by one, into a stark, well-lit chamber.  
- A long stone desk stretches across the room. Behind it sits [[Caroline]], the stern and imposing woman who led our capture. She's clad in ornate armour, bearing signs of authority and battle alike.  
- [[Caroline]] reveals that the [[Archaeologist Guild]] was a front - her organisation has been using it to seek out and contain dangerous magical artefacts before they fall into the wrong hands.  
- With no room for protest, we are returned to our cells.  

>[!example] Short Rest
2x Hit Dice and regain 5 health

- After a brief rest, distant echoes of chaos begin to rise - shouts, metallic clashes, and something deeper, more violent. A fight is happening somewhere down the hall.  
- Suddenly, the glowing runes on the cell doors sputter, dim, and then die out entirely. The enchantment is gone. Time to move.  
- [[Obu]] slips nimbly between the bars, followed closely by [[Pissard]]. Together, they begin carefully creeping through the now-shadowed corridors.  
- In the next hallway, [[Lyra]] focuses her druidic power and transforms into a large horse, using her strength to kick furiously at the cell door, attempting to break it down.  
- [[Obu]] reaches a large, trashed room with a long table - the room we had been escorted to previously. Blood smears the stone floor. A set of keys lies discarded near a broken chair.  
- Grabbing the keys, [[Obu]] hurries back to free the remaining party members. One by one, we slip from our cells and regroup.  
- With no idea what caused the chaos, we push deeper into the prison's twisting halls, trying to stay low and alert.  
- Upon opening a heavy door at the end of a corridor, we come face-to-face with a horrifying sight
- It's a faceless, shifting creature, featureless and wrong. We've never seen anything like it.

![[Unknwon Entity.png]]

>[!tip] Encounter
>Initiative 7
>12 dmg taken
>5 dmg taken
>


