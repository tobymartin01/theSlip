---
type: session
world: Vardin
campaign: The Slip
location: Arcabourne
characters:
  - Mechamaru
  - Tibber
  - Obu
  - Mini
tags:
  - session
previous_session: "[[Session 07]]"
date: 2025-08-27
banner: https://t3.ftcdn.net/jpg/12/89/71/44/360_F_1289714418_H2BtmfYlt2Ths8ZJXaKf1xP3FEiYiMX2.jpg
banner-fade: -160
---
# **Outside the Sewers**

- Knowing we need information about the mysterious **[[Vayron Manor]]**, we recall our old “contact” — **[[Darwin]] the rat**, the shady informant who previously gave us leads for the **[[Archaeologist Guild]] heist**.
    
- If anyone in the city’s underbelly knows the manor’s secrets, it would be him.
    
- With that in mind, we set our course for the market, hoping to track Darwin down before nightfall.
    

---

# **The Market**

- The market is alive with sound and colour, merchants shouting their wares beneath banners, hawkers peddling spices and trinkets, and the smell of grilled meats drifting through the air.
    
- **[[Obu]]** is immediately sidetracked by a **beautiful vase filled with wild flowers**, leaning close to admire the colours while the rest of the party tries to stay focused.
    
- Meanwhile, **[[Tibber]]** spots a **dark alley** branching away from the bustle of the market.
    
- From the shadows, a thin figure emerges — it’s **[[Darwin]]**, as twitchy and sly as ever.
    
- We attempt to gather information on the manor, but Darwin proves as slippery as usual.
    
- **[[Tibber]]** parts with a copper coin for a vague and useless tip, only to demand it back with a growl. His intimidation works, but Darwin melts back into the shadows, vanishing before we can press further.
    
- Our potential advantage is lost. With nothing more to gain here, we decide to head to the pub and bide our time until night.
    

---

# **The Tavern**

- The tavern is dimly lit and lively, the smell of stale ale and smoke lingering in the rafters.
    
- We order a round, letting the hours pass in conversation and quiet preparation for what’s to come.
    
- As the city darkens, anticipation builds. Soon, it is time.
    

---

# **[[Vayron Manor]]**

- The streets leading to the manor are lit by **cold, steady synthesis lamps**, each placed about twenty feet apart. Their eerie blue glow makes the empty street feel more like a stage set for our intrusion.
    
- Two guards stand outside the imposing front doors. We launch a quick attack, though risky and chaotic, we manage to subdue them and slip inside.
    
- Entering the grand foyer, **an umbrella vase topples over**, clattering loudly across the marble floor. We freeze, listening for signs of movement.
    
- Silence. No one stirs. But **[[Obu]]’s sharp eye notices one umbrella out of place**, a luxurious handle, carved into the shape of a dragon’s head. Closer inspection reveals it is **stained with blood**.
    
- The **opulent dining room** (the very room where we had first met the young master) now lies eerily empty, untouched.
    
- Searching the pantry, **[[Tibber]] discovers a bloody sack**. Tense at first, he opens it to reveal nothing sinister — only raw pork chops. Still, the sight adds to the unease.
    
- On the staircase, disaster strikes. **[[Obu]] trips and tumbles**, sending the entire party into a heap on the carpet. The crash resounds through the halls.
    
- Footsteps shuffle above us. Lights flicker on. The residents are waking.
    
- In panic, we rush to find cover, only for [[Obu]] to **slip and fall again** while retreating down the stairs, adding to the chaos.
    
- Amid the confusion, **[[Tibber]] frightens the young master**, who bolts in terror.
    
- We give chase up the staircase, pursuing him into the **master suite** where **[[Obu]] manages to subdue him**.
    
- Under pressure, the truth spills out:
    
    - The young master had fallen out with his father.
        
    - The inheritance was to go to his cousin, leaving him with nothing.
        
    - In desperation, he plotted a **kidnapping** to force control of the family fortune.
        
    - But events spiraled — the father was murdered, and the young master shifted blame outward by demanding an official investigation.
        
- We push the idea of hush money, but it quickly becomes clear the **family is broke**. Their wealth, once tied to the steelworks, evaporated when **synthesis technology** made their industry obsolete. The manor’s opulence is nothing more than an empty shell.
    
- With nothing to gain and no reason to protect him, we drag the young master from his suite.
    
- Our decision is clear: he will be handed over to the authorities.