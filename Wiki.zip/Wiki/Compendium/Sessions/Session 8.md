---
type: session
world: Vardin
campaign: The Slip
location: 
characters: 
tags: 
previous_session: 
date: ""
banner: https://t3.ftcdn.net/jpg/12/89/71/44/360_F_1289714418_H2BtmfYlt2Ths8ZJXaKf1xP3FEiYiMX2.jpg
banner-fade: -160
---

# Title
