---
date: 2025-05-27
location: Arcabourne
type: session
world: Vardin
---

#session 
Previous session: [[Session 2]]

# Cleaning Wounds - Archaeologist Guild
- defeated the [[Sentinel]] sentries
- gained entrance to the spiral staircase after reading the Verse on the podium
- Unconcious
	- Death saving success for first roll
	- Death Saving Success
- Helped up by Lyra with helping hands
- Fall off balcony in next room
- fail all strength checks
- fall into the abyss
- Dead....
