---
type: session
world: Vardin
campaign: The Slip
location: Arcabourne
characters:
  - Lyra
  - Obu
  - Mechamaru
  - PS
  - Tibber
  - Mini
tags:
  - session
previous_session: "[[Session 5]]"
date: 2025-07-30
banner: https://www.dndspeak.com/wp-content/uploads/2021/04/Prisoner-1.jpg
banner-fade: -160
---

# Prison Break - The Glizzard

>[!example] Interaction
Heal 7 health

- We continue deeper into the prison block. Immediately, the **sounds of battle echo** through the darkened interior - the **clash of metal**, the **scraping of claws across stone**, and then a **deep, guttural roar** that rattles us to the bone.
- A **massive figure lumbers into view**, partially obscured by shadow. Its form is inhuman, twisted, and powerful - it is a **[[Stalker]]**, a deadly evolution of the creature we faced earlier.
- The **previous creature**, which now seems almost pitiful in comparison, was identified as a **[[Hollow]]** - malformed and dangerous, but not nearly as formidable.

>[!tip] Encounter
>Initiative 21
>1 Ki point expended for flurry of blows (all attacks missed)
>Land an attack, attempt flurry again costing ki, miss both
>[[Caroline]] enters, bless with +2 attack and Damage, +1 AC
>Attack, nat 1, attack of opportunity...
>Receive 18 dmg - > -10 hp
>Unconscious...
>[[Desmond]] stabilises [[Obu]], gets up at 1hp
>Nat 1, get slapped. Receive 18dmg -> -17hp
>Stabilised by [[Desmond]] but still unconscious
>Monster vanishes, [[Caroline]] says its still around
>[[Desmond]] succeeds on CPR, -> 1hp
>Monster is defeated

- With the Stalker subdued and the warehouse cleared, we **ascend the stairs** leading back to the surface, the echoes of the encounter still ringing in our ears.
- **Outside, the street has transformed**: a **security perimeter** has been established around the building. **Archers take positions on rooftops**, **barricades** line the perimeter, and **armoured guards** maintain watch, weapons drawn and tense. The situation is being tightly contained.

# Freedom

- As we regain our bearings, a **large, ornate carriage** rolls to a halt nearby. It is **open-topped**, richly decorated, and drawn by **four elegant horse-shaped automatons**, their metal limbs clinking with each precise movement.
- **[[Caroline]]**, poised and commanding, beckons us with a nod. She gestures toward the carriage: *“Time to go. We have much to discuss.”*
- The party climbs aboard. The **carriage lurches forward**, surprisingly smooth despite its size and weight.
- We're headed to the **[[Argyle Guild Hall]]**, the heart of the organization we've now entangled ourselves with.
- As the ride continues, we **meet the rest of the team**, finally united:
	- **[[Lyra]]**
	- **[[Mechamaru]]**
	- **[[Tibber]]**
	- **[[Mini]]**
- The city around us is unnaturally quiet. **Morning fog coils between the buildings**, dimming the glow of **street lamps as they flicker off**, one by one. The **early dawn casts a grey pallor** across the cobblestones. It feels like the calm after a storm - or just before the next one.

# [[Argyle Guild Hall]]

- We are guided into **[[Caroline]]’s office**, a space that is both elegant and utilitarian - maps on the walls, documents stacked with precision, and a faint smell of ink and oil.
- [[Caroline]] leans forward and lays it out plainly:
	- *“I have a proposition. One that doesn’t go through official channels.”
- [[The Argyles]] Guild is looking for a **black ops team** — deniable, flexible, trusted. A group they can send on **covert missions**, the kind that require results without questions.
- In addition to **routine work**, we would be **activated when discretion and force are equally needed**.
- After a moment of quiet agreement, we accept.
- Our terms: **3 crystals and free pints** at any guild-approved pub.
- **Officially unofficial**, we are handed **badges bearing [[The Argyles]]’ crest** - simple, elegant, unmistakable.
- ![[argyle_guild_badge.png]]
- The room hums with quiet purpose as we accept them, knowing there’s no turning back.

# Level Up!

- The events of the day have pushed us further - our skills sharper, our resolve hardened.
- **LEVEL UP!**
	- **Level 2 → Level 3**
	- **Health** has increased, **deflect missiles** and **open hand technique** have been acquired.









