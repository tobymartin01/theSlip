---
type: session
world: Vardin
campaign: The Slip
location: Arcabourne
characters: 
tags: 
previous_session: "[[Session 6]]"
date: 2025-08-06
banner: https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fimages.nightcafe.studio%2Fjobs%2FHmtVK1Aq6LTobSCM9vUM%2FHmtVK1Aq6LTobSCM9vUM--1--lfaqs.jpg%3Ftr%3Dw-1600%2Cc-at_max&f=1&nofb=1&ipt=801e91999ec07132638d92c8c0f4e175aa7d7e213c06c68499632df16519db4c
banner-fade: -160
---

# [[Argyle Guild Hall]]
- Morning after hurried introduction into the [[Arcane Guilds]]
- We have been designated Argyle team omega
- We need to come up with a team name to use outside of the black ops designation, Scrolls and Trolls it shall be.
- 
