---
banner: "![[Compendium/Resources/Maps/marked_world_map.png]]"
type: session
date: 2025-04-14
campaign: The Slip
world: Vardin
location: Arcabourne
previous_session: "[[Session 00]]"
tags:
  - session
---


# New Beginnings - [[Arcabourne]]
- Visiting the city in search of a rare herb said to assist in healing slip corruption
- In a travel with strangers (rest of the party) travelling to the city
	- [[Lyra]] - elf, archaeologists guild
	- [[Kamarik]] - sleeping, archaeologists guild
	- [[Mechamaru]] - automaton, lives in Arcabourne, researcher (synthesis and the slip, 130 years old)
	- [[Vailenn]] - archaeologists guild
- Arrive at [[Arcabourne]]
	- airships
	- watchfires of automatons on the walls
	- towering, bustling but the feeling of being watched doesn't disappear
- gates don't open immediately. driver comes up to the carriage window, dirty and scarred face
- Asking for papers and coins
- Hand over Healer papers and 1 silver coin

>[!example] Interaction
-1 silver piece
-1 Healer Papers

- coin needed as healer papers aren't too much of an ideal entrant
- guards scan the carriage and no issues. driver passes over papers and bribe and we pass into the city
- winding streets, mossy and uneven. ruins scatter the roadside. but the pulse of progress hums. the industrial revolution with the rise of automatons. the smell of oil and wet stone lingers in the air
- Passengers like ourselves dismount from the carriage and grab our respective belongings
- Driver hands back papers

>[!example] Interaction
+1 Healer Papers

- Group up and head towards archaeology guild and apothecary.
- Archaeology building looks like a large repurposed church, not quite cathedral but significant. Sign outside with the text "The Archaeologist Guild"
- The party splits, the trio head into the [[Archaeologist guild]], me and [[Mechamaru]] head towards the Apothecary
- Contrary to the city, the building is old and rustic
- toss a copper piece to [[Mechamaru]] for the help

>[!example] Interaction
-1 copper piece

# The Apothecary
- Enter the building, cliché bell dings as we enter
- large interior, overwhelming smell of herbs and flowers, scattered along the walls. many are familiar but some allude
- a Gnome ([[Curtis]]) sits behind the counter
- I ask about the new mysterious herb
- Auban? herb in a small box, similar to engagement ring box. dried leaves, similar to sage
- Harvested from corrupted areas, hard to get hold of
- Receive the box
- most potent when fresh
- While in the shop, restock healing supplies

>[!example] Interaction
-3 silver pieces
+1 herb stockpile

- leaves the shop and bids farewell to [[Mechamaru]]

## The City
- Attempt to wander the city looking for other healers or medical centres
- get lost immediately
- Enter a sketchy alleyway
- greeted by thugs
- intimidated them off, avoiding any violence
- [[Mechamaru]] escorts me to inn so I don't get lost again

## The Inn
- Arrive at the inn and purchase a drink after the previous incident. [[Mechamaru]] just sits there and watches, emotionless

>[!example] Interaction
-1 copper piece
+1 ale 

- knock back the ale quickly, refreshing and needed after exploring round the city

>[!example] Interaction
-1 ale

- complete lightweight, already inebriated
- meet everyone else back at the inn
- get pissed
- [[Vailenn]] also gets drunk and begins to ramble incoherently about a crystal, heist, money, break-in, etc
- I'm curious but we two are both too intoxicated to have any productive conversion
- [[Vailenn]] passes out, we as a party purchase a room. I fail to carry [[Vailenn]] up to the room, falling flat on my face
- [[Mechamaru]] carries us both up to room
- collapse onto nearest bed


