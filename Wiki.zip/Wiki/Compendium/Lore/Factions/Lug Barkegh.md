---
type: faction
---

The Gnorl Pirates - named after their founder, a large Orc Leader called Gnorl. They are the only being in the world to have single handily slain a Kraken. Supposedly. 

Pirates with honour are a scarce sight on the waters. But it is the chief reason as to why these ones have lasted so long. When the Gnorl raid, or attack a ship, there are of course casualties, however they only want plunder and a good scrap. Once you give up your valuables they'll leave you be. 

They're also very welcoming of other species, if you can fight and want to get rich - welcome to the club, you're now an honourable Orc. 

This honour system in large part one of the main reasons they've been active without outside interference for so long, many Nations do not have a significant Navy - and do not see the cleansing of the Gnorl Isles as a worthwhile endeavour - nor profitable. They also have a habit of keeping other smaller pirate groups in check, sometimes either absorbing or even outright wiping them out. 
