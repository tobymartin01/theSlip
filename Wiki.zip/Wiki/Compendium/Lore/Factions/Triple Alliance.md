---
type: faction
---

The **Triple Alliance** ([[Tylian Kingdom]], [[Aplaria]], and [[Sceca]]) exists mainly to counter the threat of the [[Florian Commonwealth]], though the nations distrust each other.