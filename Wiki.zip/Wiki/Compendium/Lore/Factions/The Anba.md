---
type: faction
---

A group of wandering doctors, vary rarely show their faces. Wear different animal masks detail what branch they specialise in. The detail of the mask and outfit marks their rank and training in medicine. 

The Animals are as follows:

- Owl - Mass Curse Control and Magical Diseases 

- Crow - Traditional Doctors, trained at treating large amounts of patients 

- Eagle - Mundane Diseases and Terminal Care. Often used by Royals, Nobles and other National Leaders 

- Vulture - Specialise in battlefield wounds - often tending to both sides during a conflict. While this has generated some tension in the past, this particular branch is held in the most respect.