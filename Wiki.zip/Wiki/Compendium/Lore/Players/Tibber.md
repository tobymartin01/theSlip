---
type: player
status: alive
---
Fighter? has rage