---
banner: "[[Pax_profile_image.png]]"
banner-x: 48
banner-y: 32
banner-height: 640
type: player
status: dead
---
# Character Sheet:  
![[Pax Character Sheet.pdf]]
# Backstory
### **The Echo of [[Varadinium]]**

I was never meant to be discovered.

Born with a face that was not my own, I learned early on that secrecy was survival. I lived in **[[Varadinium]]**, the heart of the **[[Florian Commonwealth]]** - a city of gleaming towers, rigid order, and military discipline. The Commonwealth prided itself on control, strength, and structure. It had no patience for uncertainty. No room for someone like _me_.

I did what I had to in order to blend in. One face for the streets, another for the marketplace, another still when I worked as a scribe - just another faceless citizen in a city that valued uniformity, going often by the alias **Ogwen**. I should have been safe. I _thought_ I was safe.

But secrets have a way of slipping through cracks.

Maybe someone saw me change when I thought I was alone. Maybe an old friend noticed that my face did not age as theirs did. Or perhaps it was just suspicion - baseless, but dangerous all the same. Whatever it was, whispers began to spread: _Changeling. Liar. Monster._

At first, I ignored them. Then, people stopped looking me in the eye. They crossed the street when they saw me. Then came the stones.

And then came **him**.

One of the **Commonwealth’s high-ranking guards** - a veteran of conquest, a man who had fought in wars and deemed himself above the likes of me. He had been drinking that night, or maybe he just wanted a reason. The accusations didn’t need proof. He found me in the street, cornered me, and decided he would _teach me a lesson_.

The lesson did not go as he intended.

I do not remember much - just the crack of a fist, the feel of cold stone against my back, the weight of him above me. Then came the struggle, the rush of panic, and the sudden sharpness of **his own dagger** in my hands.

When it was over, he was dead. And I was already running.

---

### **The Road and the Healer’s Mask**

I knew the **Commonwealth’s laws** - there would be no trial, no plea for mercy. Just a swift execution. The Republic’s machine turned on efficiency, and _my death would be nothing more than another footnote in its ledgers_.

So I ran.

I slipped past the patrols, changed my face half a dozen times before the gates, and vanished into the night. By the time the sun rose, **[[Varadinium]] had lost a nameless citizen, and the roads had gained a wandering monk**.

Now, I am just a **humble healer**, traveling under a new name. I offer aid to the sick and injured, a quiet figure in tattered robes, staying on the fringes of civilization. I avoid the great capitals where my past may still linger. I never stay anywhere too long.

I have wandered through the **[[Triple Alliance]]’s lands** - through the forests of **[[Tylian Kingdom]]**, where their **riflemen** watch the borders, and the warships of **[[Aplaria]]** rest in their harbors. I passed through **[[Sceca]]**, where knights on horseback rule from their crumbling castles, their people whispering of rebellion.

I have seen the deserts of the **[[Ospesh Empire]]**, where water is sacred, and the merchant-princes trade in glass and spice. I have moved through the trade hubs of **[[Oricia]]**, where the sails of airships fill the skies.

I avoid **[[Whuaz Khanate]]** and its endless plains, where **nomadic raiders** might sell me out for a pouch of gold. I stay away from **the [[Florian Commonwealth]]’s borders**, where my name - my _real_ name - may still be spoken in hushed voices.

And I do not dare step foot in **[[Agadir Sultanate]]**, the deeply religious sultanate that sees Synthesis as heresy.

For now, I am safe. For now, I walk the road, offering healing where it is needed, keeping my secrets buried.

But I do not know how far the **[[Florian Commonwealth]]’s reach** extends. And I do not know if the past will one day come looking for me.

---

### **Potential Conflicts / Interactions**

- **The Commonwealth’s Shadow** - Someone from **[[Varadinium]]** may still be looking for me - a bounty hunter, an old friend, or a ghost from my past.
- **The Price of Secrets** - In a world ruled by technology and order, a changeling is an _anomaly_ - a creature that cannot be easily catalogued or controlled. Will someone try to exploit that?
- **Marked** - I have some sort of blemish/scar that persists between changes aiding in others potentially recognising me. Maybe forearm or forehead (often covered by hood), somewhere hidden but with potential to be exposed and noticed

---

1. The Nature of the Slip & Dwellers

The Slip was a catastrophic event that reshaped reality, and its remnants still linger. Monks may have a deeper, meditative understanding of how the world changed, perhaps even believing that reality itself is fractured. Dwellers are more than just monsters—they are echoes of another existence. Some monks theorize that understanding their nature might offer insight into the universe’s balance.

2. Magic & Synthesis

True magic is rare, and monks would revere it as something almost divine or cosmic. They might see its loss as part of the world's punishment or a cycle of rebirth. Synthesis, though powerful, is artificial. Some monks debate whether it is a tool of salvation or another path to destruction.

3. Paths of Survival

A wandering monk would know ancient paths, hidden shrines, and safe havens that travellers, refugees, or outcasts might rely on. They could recognize signs of Dweller activity—strange weather changes, unnatural silence, or distortions in light and shadow.

4. The Balance of Power Among Nations

While monks may remain neutral, they are not ignorant. They know the tensions between the [[Tylian Kingdom]], the [[Florian Commonwealth]], and the other nations. Some monks believe the world is due for another great war, while others search for ways to prevent it.

5. Ancient Teachings & Forbidden Knowledge

Some monasteries have preserved old texts that predate [[The Slip]], containing forgotten histories or techniques lost to time. There are whispered legends of monks who trained their bodies to resist the influence of Dwellers or even harness fragments of magic still lingering in the world.

6. Philosophy of the Wanderer

"The road does not end, only the traveller does." A monk understands that [[Vardin]] is ever-changing, and true enlightenment is found in motion. Some monks dedicate their lives to protecting others, while others believe in complete detachment, seeing worldly struggles as temporary in the grand design.
# Stats


---
### **Name:** Pax

### **Race:** Changeling

### **Class:** Monk 

### **Background:** Hermit 

### **Alignment:** Neutral Good
---
### Health: 10/20

### Speed: 40(unarmoured)/30(armoured)

### AC: 15

### Initiative: +2

### Stats

| Stat         | Value | Modifier |
| ------------ | ----- | -------- |
| Strength     | 8     | -1       |
| Dexterity    | 15    | +2       |
| Constitution | 16    | +3       |
| Intelligence | 8     | -1       |
| Wisdom       | 17    | +3       |
| Charisma     | 7     | -2       |
### Saving Throws
| Stat         | Modifier |
| ------------ | -------- |
| Strength     | +1       |
| Dexterity    | +4       |
| Constitution | +3       |
| Intelligence | -1       |
| Wisdom       | +3       |
| Charisma     | -2       |
### Skills
| Skill           | Ability      | Proficiency | Modifier |
| --------------- | ------------ | ----------- | -------- |
| Acrobatics      | Dexterity    | Yes         | +4       |
| Animal Handling | Wisdom       | No          | +3       |
| Arcana          | Intelligence | No          | -1       |
| Athletics       | Strength     | No          | -1       |
| Deception       | Charisma     | Yes         | +0       |
| History         | Intelligence | No          | -1       |
| Insight         | Wisdom       | Yes         | +5       |
| Intimidation    | Charisma     | No          | -2       |
| Investigation   | Intelligence | No          | -1       |
| Medicine        | Wisdom       | Yes         | +5       |
| Nature          | Intelligence | No          | -1       |
| Perception      | Wisdom       | No          | +3       |
| Performance     | Charisma     | No          | -2       |
| Persuasion      | Charisma     | No          | -2       |
| Religion        | Intelligence | Yes         | +1       |
| Sleight of Hand | Dexterity    | No          | +2       |
| Stealth         | Dexterity    | No          | +2       |
| Survival        | Wisdom       | No          | +3       |
### Attacks
| Ability        | Attack (+Bonus) | Damage (+Bonus) |
| -------------- | --------------- | --------------- |
| Unarmed Strike | 1d20+2          | 1d4+2           |

### Abilities [1/2 Ki]

| Ability          | Type         | Cost | Desc                                                                                             |
| ---------------- | ------------ | ---- | ------------------------------------------------------------------------------------------------ |
| Flurry of Blows  | Bonus Action | 1 Ki | After you take Attack action, spend 1 ki to make 2 unarmed strikes.                              |
| Martial Arts     | Bonus Action | -    | Make an extra unarmed strike when you take Attack action.                                        |
| Patient Defense  | Bonus Action | 1 Ki | Spend 1 ki point to take the Dodge action.                                                       |
| Step of the Wind | Bonus Action | 1 Ki | Spend 1 ki point to take the Disengage or Dash action and jump distance is doubled for the turn. |

### Money

| Form         | Amount |
| ------------ | ------ |
| Gold Piece   | 0      |
| Silver Piece | 58     |
| Copper Piece | 7      |

### Items
| Item           | Amount |
| -------------- | ------ |
| Herbalism Kit  | 1      |
| Healer Papers  | 1      |
| Herb Stockpile | 1      |

