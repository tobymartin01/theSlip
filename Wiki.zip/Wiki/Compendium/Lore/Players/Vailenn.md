---
type: player
status: dead
---
Also known as Piss Wizard