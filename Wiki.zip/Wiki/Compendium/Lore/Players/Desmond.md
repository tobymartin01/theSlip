---
type: player
faction: 
location: 
world: Vardin
campaign: The Slip
description: 
race:
  - Owl
gender: Male
class: Wizard
---
Business parter with [[Obu]]