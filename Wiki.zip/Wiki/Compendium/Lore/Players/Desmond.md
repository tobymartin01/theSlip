---
type: player
faction: 
location: 
world: Vardin
campaign: The Slip
description: Owl man wizard fella
race:
  - Owl
gender: Male
class: Wizard
status: alive
---
Business parter with [[Obu]]