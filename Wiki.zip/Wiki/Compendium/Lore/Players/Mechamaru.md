---
type: player
status: alive
---
Automaton