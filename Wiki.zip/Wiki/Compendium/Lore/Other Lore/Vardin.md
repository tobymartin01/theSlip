#loredump
# **World Background: The Year is 211 AS - After Slip**

The Slip is the moment when two different realities intersected with ours. One allowed monsters of all sizes, shapes, and horrors to hop into our dimension unopposed. The other acted as a drain, sucking valuable magic out of the world - leaving those who wield it a valuable and rare resource.

People are divided on what caused such a cataclysmic event. Some believe it was an act of the Gods to punish sinners and unbelievers, while others see it as some cosmic joke, happening on such a slight chance.

They called them **The Dwellers** - those that dwell in the night and shadows. That flicker of movement out of the corner of your eye, the nightmare you just can’t escape.

## **The Age of Monsters and Terror**

The armies of the world floundered against these beasts, some so horrible it is said they were the physical manifestations of nightmares. Some forced you to live them; others brought them to life before your eyes. Some were so terrifying that soldiers would immediately fall upon their own blades to rid themselves of the sight.

Nations and species, once caught up in their own conflicts, were unprepared for the onslaught that followed. Entire towns and villages were swallowed, leaving nothing but ruins and slaughtered people.

Thus, the world entered a new Dark Age - the **Age of Monsters and Terror**.

For nearly 70 years, the world struggled against the darkness. Armies of thousands were sacrificed to bring down even a single creature, so great was their terrible power.

## **The Rise of the Argyles and Synthesis**

Then came salvation - groups of powerful individuals banded together. They called themselves **Argyles**, named after the first **Godwin Argyle**.

With the aid of the Argyles, the tide slowly turned. But it wasn’t enough - until both a technological and magical marvel was created.

They called it **Synthesis** - crystallized magic.

Synthesis could power all kinds of machines: ships that could fly, artificial lights, mechanical horses, and other automatons. But most importantly, it was used to create **armor and weapons** capable of fighting the Dwellers.

Together with the Argyles, **Vardin** led a counterattack against the darkness. The creatures fell in droves, and it wasn’t long before the dire situation began to turn around.

## **The Present: An Uneasy Peace**

Over a hundred years later, the beasts still exist in the world - still a menace but not to the degree they once were. They still ravage the countryside and occupy the dark places of the world.

The Argyles, seeing their diminished need, banded together into **guilds**. These guilds spread to all major capitals, offering their services to nations, businesses, and individuals. Over time, they evolved into powerful organizations, specializing in various fields - **technology, research, and diplomacy**, becoming integral to the world's **new social and political structure**.

### **Life in a Fractured World**

While the world adapted to the presence of monsters lurking in the shadows, it was far from the utopia that once existed.

- **The Dwellers were not vanquished** - they were merely **scattered**. Some still ravage the wilderness, while others blend into civilization, waiting for their chance to strike again.
- Cities that were once beacons of light and culture **became fortresses**. Their streets are patrolled by **Synthesis-powered automatons**, and their walls are guarded by the **best of the Argyle-trained warriors**.
- **Magic has become rare and precious**. Only those with the knowledge and ability to harness it are able to wield it. Those who can still use magic are **revered, feared, or hunted**.

### **The Power Struggle of Synthesis**

The rise of **Synthesis technology** brought **both a blessing and a curse**. While it allowed the world to defend itself, it also created new **power imbalances**:

- **Kingdoms fight over access to Synthesis**, as it powers everything from **airships** to **fortresses** that can withstand any assault.
- Entire **armies are outfitted** with magical-infused armour and weapons.
- Some factions have turned **Synthesis into an instrument of control**.

## **The Future of the Argyles**

The Argyles played a crucial role in turning the tide, but **their influence has begun to wane**. As peace settled into an uneasy balance, their role in fighting the creatures of the dark diminished.

- Some **Argyles became mercenaries**, offering their combat skills for hire.
- Others began to **seek answers** about the true nature of the **Slip**, wondering if they could **prevent** another catastrophe.
- Some **explore the cracks between realities**, hoping to uncover more about **the Dwellers** or even stop them entirely.

## **The Balance is Shifting**

The world now lives in an age of uneasy peace.

The monstrous horrors of the Slip still **wait for their chance to return in full force**, and knowledge of the ancient war - once a fight for survival - is now a whispered tale, considered a relic of the past.

But **some know the truth**:

🔹 **It’s only a matter of time before the balance shifts again.** 🔹
# Nations of the World

![[marked_world_map.png]]

![[blank_world_map.png]]
## **(Light Blue) [[Tylian Kingdom]]**

**Capital:** [[Arcabourne]]

- A small but powerful nation, and birthplace of the Argyles. Its army is large, professional, and well-equipped, keeping both the Florian Commonwealth and the Khanate at bay.
- Their most powerful regiments of riflemen use 'Synthesis' to create powerful long-range weapons.
- The **Triple Alliance** (Tylia, Aplaria, and Sceca) exists mainly to counter the threat of the Commonwealth, though the nations distrust each other.
- The economy is transitioning from agrarian to industrial due to Synthesis, shifting power from the nobility to oligarchs and merchants.
- Despite the current king's efforts to maintain stability, a brewing power struggle looms on the horizon.

---

## **(Red) [[Florian Commonwealth]]**

**Capital:** [[Varadinium]]

- A **highly militarized** nation focused on conquest, closely watching the continent while being kept at bay by the **Triple Alliance**.
- The **oldest Republic in the known world**, governing for nearly 3,000 years through a 100-member body, led by two elected officials who serve a **single six-year term**.
- Leadership positions are often held by **military generals**, reflecting the nation’s militarized culture.

---

## **(Orange) [[Aplaria]]**

**Capital:** [[Kokeri]]

- A relatively young nation, originally a loose coalition of **tribal raiders**. Only after facing an external invasion did they unify into a central government.
- Economy is the weakest among the **Triple Alliance**, relying on **mining, logging, and fishing**.
- Possesses **the strongest navy**, specializing in fast and powerful strikes.
- Army is centered around a **core of elite infantry**.

---

## **(Lavender) [[Sceca]] (C-ka)**

**Capital:** [[Stormfall]]

- Military is small but revolves around **heavy cavalry**.
- **Matriarchal leadership** creates tensions within the Triple Alliance.
- The economy is **in decline** due to stagnation and corruption, with leaders focused on personal wealth.
- Nationalist sentiment is rising, and brutal suppression of revolts has only **exacerbated unrest**.

---

## **(Yellow) [[Ospesh Empire]]**

**Capital:** [[Alistan]]

- An **oriental nation** with an economy based on **spice trade and glass production**.
- Limited population due to **harsh desert conditions**, making it one of the **smallest militaries** in the region.
- Cities are built around **oases and underground water reserves**, which are held as **sacred**.

---

## **(Cyan) [[Republic of Oricia]]**

**Capital:** [[Consentia]]

- A **largely peaceful** trading nation with strong relations with most others.
- Hosts one of the **strongest economies**, fueled by vast trade fleets and deep investments into **Synthesis technology**.
- Recently invented **airships**, further strengthening their economic influence.

---

## **(Purple) [[Whuaz Khanate]]**

**Capital:** [[Nonowon]]

- A **nomadic nation** of tribal horsemen roaming the **Ogemer plains** (Nogoon Tengis).
- Very few cities exist, only **three main settlements**, including the capital Nonowon.
- Economy revolves around **raiding**, though recent years have seen these kept in check by **forts along their borders**.

---

## **(Dark Blue) [[Agadir Sultanate]]**

**Capital:** [[Wadan]]

- Shares history and culture with the Ospesh, having migrated across the **Vestia Sea** centuries ago.
- **Religious nation**, rejecting Synthesis as an affront to their gods, leading to **isolationist policies**.
- Economy has **collapsed** due to cutting off trade, leaving **rotting agricultural goods** with no buyers.

---

## World Background, the year is 211 AS - After Slip. 

The slip is the moment when two different realities intersected with ours, one allowed monsters of all sizes, shapes and horrors to hop into our dimension unopposed. The other, acted as a drain, sucking valuable magic out of the world - leaving those who wield it a valuable and rare resource. 

People are divided on what caused such a cataclysmic event, be it an act of the Gods to punish sinners and unbelievers, or some cosmic joke for this to happen on such a slight chance. 

They called them - The Dwellers - those that dwell in the night and shadows. That flicker of movement out the corner of your eye, the nightmare you just can't escape. 

The armies of the world floundered against these beasts, some so horrible it is said they were the physical manifestations of your nightmares. Some caused you to live them, some brought them to life before your eyes. And some were so horrifying soldiers would immediately fall upon their own blades to rid themselves of the sight of them. 

The nations and species of the world, so caught up in fighting each other, we unprepared for the onslaught that followed. Entire Towns and villages were swallowed, leaving nothing but ruins and slaughtered people. 

The world entered a new Dark-Age, the Age of Monsters and Terror. 

For nearly 70 years the world struggled against the dark, armies of thousands were sacrificed to bring down some of these creatures, so great was their terrible power. 

But then came their salvation, groups of powerful individuals banned together - they called them Argyles after the first Godwin Argyle. 

With the aid of the Argyles, the tide slowly turned. But it wasn't enough to curtail all, when finally both a technological and magical marvel was created. 

They called it Synthesis, crystallised Magic. 

Able to power all kinds of machines, ships that could fly, artificial lights, mechanical horses and other automatons, but most importantly - armour and weapons that could be used to fight. 

Together with the Argyles, Vardin pushed back against the darkness - the creatures fell in droves as Vardin pressed their counter attack, and it didn't take long for the dire situation to turn around. 

Over a hundred years later, the beasts are still present in the world - still a menace but not to the degree they once were. They still ravage the countryside, and occupy the dark places of the world. The Argyles, seeing their diminished need, banded together creating guilds to work together and spread out jobs among all that could. These guilds would spread to all major Capitals of the world, lending their services to nations, businesses, and individuals in need of their unique skills. These guilds, however, weren't just for monster-hunting. Over time, they evolved into powerful organizations that specialized in a variety of fields—technology, research, and even diplomacy—becoming integral to the world's new social and political structure. 

While the world had adapted to live with monsters lurking in the shadows, it was far from the utopia that once existed. The Dwellers, as they were called, were not vanquished but were now cornered, scattered into hiding. Some still ravaged the wilderness, while others blended into the corners of civilization, waiting for their chance to strike again. Cities that were once beacons of light and culture became fortresses, their streets patrolled by the latest in Synthesis-powered automatons, their walls guarded by the best of the Argyle-trained warriors. 

Magic had become a rare and precious resource. Only those with the knowledge and ability to harness its dwindling power were able to wield it, and even they were considered to be valuable commodities in a world that had become desperate for every bit of power it could muster. Those who could still use magic were revered, feared, or hunted. The scarcity of magic meant that each spell was worth more than gold, and so powerful magic users were often the most valuable (or dangerous) individuals in society. 

The rise of Synthesis technology, created from crystallized magic, had been both a blessing and a curse. While it allowed the world to defend itself, it also created a new wave of power imbalances. Kingdoms fought over access to Synthesis, as it powered everything from airships that could traverse once-inaccessible lands, to massive fortresses that could withstand any assault, to enormous machines that could help rebuild what had been destroyed. Entire armies were outfitted with magical-infused armor and weapons, with some factions turning the technology into instruments of control. 

Though the Argyles played a crucial role in turning the tide, their influence had begun to wane over the centuries. As peace settled into an uneasy balance, the need for Argyles to fight the creatures of the dark diminished. Yet, they still remain the only true defense against the growing menace that still slinks through the night. Some Argyles took on more lucrative endeavors, offering their knowledge and combat skills as mercenaries for hire. Others began to look inward, pondering the true nature of the Slip, wondering if the answers lay in understanding the worlds that had collided. Some sought to explore the cracks between realities, hoping to uncover more about the beings known as the Dwellers, or perhaps even to stop them entirely. 

The world now lives in an age of uneasy peace. The monstrous horrors of the Slip still wait for their chance to return in full force, and the knowledge of the ancient war—fought at the brink of extinction—is now a whispered tale, often considered a relic of the past. But there are those who know that it’s only a matter of time before the balance shifts again. 

### (Light Blue) [[Tylian Kingdom]] - Captial: [[Arcabourne]] 

● A small but powerful nation, and birthplace of the Argyle's. It's army is large and professional and well equipped and has thus far kept both the Florian Commonwealth and the Khanate at bay barring a few border skirmishes with the later. Their strongest link being their powerful regiments of 'riflemen' using 'Synthesis' to create new powerful weapons capable of killing a man for a great range. 

● The triple Alliance is held purely by the threat of the Commonwealth, the three nations involved having mutual distrust and dislike between them. 

● Their economy is growing into a powerhouse, growing from a former agrarian society into a industrial one with the introduction of synthesis. This is had the effect of shifting power from the Lords and other nobles that make up the nation, into hands of oligarchs and other business owners and merchants. Although the current King has kept things quiet, there is a brewing power struggle on the horizon. 

### (Red) [[Florian Commonwealth]] - Capital: [[Varadinium]] 

● A highly militarized nation, with an economy focused on it's armies and conquest. It sits eyeing the continent with their new technology, but the Triple Alliance between Tylia -Aplaria - Sceca keeps it at bay. For now. 

● Their Republic is the oldest in the known world, having existed continuously for nearly three thousand years - a governing body of 100 men and women, highborn and lowborn headed by two elected officials who hold terms of 6 years- and only once. These offices are usually held by military Generals or similar as is tradition and a result of their militarised culture. 

### (Orange) [[Aplaria]] - Capital: [[Kokeri]] 

● Aplaria is a young nation in the grand scheme of the world, formally a mere loose coalition of tribes that raided as far south as the mysterious island nation of --. It would not be until the invasion of the outsiders that they would officially create a central government to combat the new threat. Even still many remember their nations roots, both inside and out. 

● Of the triple alliance, their economy is the weakest, heavily focused on mining, logging and fishing. But boast the strongest navy, heavily reliant on quick powerful strikes. Their army is centred around a strong core of elite infantry. 

### (Lavender) [[Sceca]] (C-ka) - Capital: [[Stormfall]]

● Their military is small, even compared to the the Ospesh, revolving heavily around their heavy cavalry. Their culture and leadership is heavily matriarchal, which rubs their two allies wrong - further straining the alliance. 

● Their economy is however in decline after decades of stagnation and limited investment, their leaders having little to do with the running of the country for several years now, and spend the time lining their own pockets. This has led to a steep rise in nationalism and many a revolt has already been swiftly and brutally put down, which has done little but stroke the flames. (Yellow) Ospesh Empire - Capital: Alistan 

● An oriental nation, with an economy heavily reliant on spice trade and glass production - due to the hot and sparse nature of the desert the people call their home it bares a limited population and one of the smallest militaries of the continent, using its natural borders and hostile climate to ward off any attack. 

● There are few cities in the nation, their populations centres being gathered around precious oasis' and underground water reserves - the liquid being held to an almost sacred degree. 

### (Cyan) [[Republic of Oricia]] - Capital: [[Consentia]]

● A largely peaceful nation, focused heavily on trading with others, near and far. Shares good relations with almost every other nation, and merchants and traders can be found in every port around the world. Despite their small size, they host one of the strongest economies thanks to their vast trade fleets, and with strong investments into synthesis, that has only grown with their invention of airships. Cul 

### (Purple) [[Whuaz Khanate]] - Capital: [[Nonowon]] 

● Much like [[Aplaria]] - the Khanate is a loose collection of nomadic tribal horseman that roam the massive plains of the Ogemer - sometimes called the Nogoon tengis. There are very few cities in their territory, there being only three to be considered as such - the Capital Nonowon and two loosely defined 'ports'. 

● Their culture and economy revolves heavily around raiding, however these have in recent years been kept in check by forts along both borders with the Ospesh and Tylia. 

### (Dark Blue) [[Agadir Sultanate]] - Capital: [[Wadan]] 

● Despite being a more temperate region, they such much of the history and culture of the Ospesh having migrated by the sea some thousands of years ago. 

● They've ignored much to do with Synthesis over the recent years, being a heavily religious nation they see the creation as a slight against their Gods - they have since become heavily isolationist, even cutting ties with their former people across the Vestia Sea. This has in turn caused a sharp decline in their economy, having relied strongly on exporting various agricultural goods - it now sits rotting in fields with no one to sell it too. 

### Notable Independent Groups -

[[The Anba]] - A group of wandering doctors, vary rarely show their faces. Wear different animal masks detail what branch they specialise in. The detail of the mask and outfit marks their rank and training in medicine. 

The Animals are as follows:

- Owl - Mass Curse Control and Magical Diseases 

- Crow - Traditional Doctors, trained at treating large amounts of patients 

- Eagle - Mundane Diseases and Terminal Care. Often used by Royals, Nobles and other National Leaders 

- Vulture - Specialise in battlefield wounds - often tending to both sides during a conflict. While this has generated some tension in the past, this particular branch is held in the most respect. 

[[Muntem]] - A predominantly Gnomish city at the tip of one of the Iron Hill's peninsulas. It is the only one of its kind, and is home to other smaller groups of species within its limits. They barter and trade with the Dwarves - such as food stuffs and leather works - which are rare among their folk. In return the Dwarves offer their protection of their short kin, and tools and other such metal works. 

[[Lug Barkegh]] - The Gnorl Pirates - named after their founder, a large Orc Leader called Gnorl. They are the only being in the world to have single handily slain a Kraken. Supposedly. 

Pirates with honour are a scarce sight on the waters. But it is the chief reason as to why these ones have lasted so long. When the Gnorl raid, or attack a ship, there are of course casualties, however they only want plunder and a good scrap. Once you give up your valuables they'll leave you be. 

They're also very welcoming of other species, if you can fight and want to get rich - welcome to the club, you're now an honourable Orc. 

This honour system in large part one of the main reasons they've been active without outside interference for so long, many Nations do not have a significant Navy - and do not see the cleansing of the Gnorl Isles as a worthwhile endeavour - nor profitable. They also have a habit of keeping other smaller pirate groups in check, sometimes either absorbing or even outright wiping them out. 

The Dwindling [[Arcane Guilds]] - Before the Slip, powerful wizarding guilds existed. Now, with magic being a rare and finite resource, these guilds have become shadowy organizations. They still control some knowledge and resources but operate in secrecy, making alliances with powerful technology groups or ruling factions. Some may hoard the knowledge of old-world magic, while others have integrated Synthesis to ensure their survival. 

[[Survivors of the Wildlands]] - After the Slip, many areas became too dangerous for civilized life. These areas are now home to survivors who live in enclaves in the wilderness, learning to adapt by using old-world ruins and magical technology to survive. They could provide strange and valuable resources or knowledge to those brave enough to enter their territory. Beardly Banking - A large banking chain that has spread across the continent, offering many services such as loans and current accounts. 

However be warned, make sure to repay your loans on time - they’re the only banking chain for a reason. 

# Historical Conflicts & Major Wars 

[[The War of the Broken Pact]] (250 years ago) – Tylia vs. Florian Commonwealth 

● A war that nearly wiped out Tylia before the rise of Synthesis. 

● The Commonwealth launched a massive invasion, breaking a previous peace treaty. 

● Tylia barely survived, relying on scorched earth tactics and guerrilla warfare. 

● The war ended in a stalemate, but Tylia never forgot the betrayal, leading to the creation of the Triple Alliance. 

[[The Crimson Rebellions]] (120 years ago) – Sceca's Civil War 

● Sceca once had a male-dominated monarchy, but a bloody uprising led by Queen Yvrenne overturned the old order. 

● The rebellion killed nearly every noble house that opposed her, solidifying the matriarchal rule that exists today. 

● Tylia and Aplaria never truly forgave this, seeing it as an unnatural shift in power. 

● This history fuels the current distrust within the Triple Alliance. 

[[The Tide Wars]] (60 years ago) – Aplaria vs. Oricia 

● Aplaria, before solidifying as a central government, raided Orician trade routes. 

● Oricia responded by hiring mercenaries and pirate fleets to burn Aplarian ports. 

● The conflict ended in an uneasy truce, but Oricia still distrusts Aplaria. 

● Today, some Orician traders demand extra security when dealing with Aplarian merchants. 

[[The Sands War]] (30 years ago) – Ospesh vs. Whuaz Khanate 

● A long conflict over access to oasis lands, as Khanate horsemen began settling near Ospesh water reserves. 

● Ospesh’s smaller military held defensive strongholds, while the Khanate used hit-and-run tactics. 

● The war ended with a reluctant ceasefire, but Khanate warlords still claim they were robbed of their rightful lands. 

[[The Trade Collapse]] (20 years ago) – Agadir Sultanate’s Decline 

● The Agadir Sultanate once thrived on agricultural exports, but its refusal to adopt Synthesis led to economic downfall. 

● Oricia cut trade ties, and Agadir’s economy crumbled. 

● This caused internal unrest, with merchants pushing for reform, but the Sultan clings to tradition. Vardin Calendar Overview 

● Total Months: 8 

● Days per Month: 42 

● Weeks per Month: 6 (7 days per week) 

● Total Days in a Year: 336 

# SEASONS & MONTHS OF VARDIN 

## SPRING (Renewal & Growth) 

1. Ciarrer – The Dawn Month 

● Symbolism: Rebirth, hope, and the end of winter’s grip 

● Major Event: First Thaw Festival – People gather to celebrate the melting snows and the return of green life. 

● Celestial Event: The Awakening Moon – A pale greenish moon, believed to be a sign of renewal. 

2. Bareday – The Month of Blessings 

● Symbolism: Fertility, prosperity, and the start of planting season 

● Major Event: Rites of the Plow – Farmers perform old rituals to bless the soil. 

● Regional Variation: The Whuaz Khanate views this as a time to scout for summer raids SUMMER (Strength & Survival) 

3. Lonnun – The Sun’s Embrace 

● Symbolism: Longest days, energy, and war preparations 

● Major Event: The Crimson Tourney held by Tylia – A brutal martial competition held in the honor of warriors. 

● Celestial Event: The Twin Suns – A rare phenomenon where a golden comet appears alongside the sun for days. 

4. Nirrek – The Month of Endurance 

● Symbolism: Hard labor, endurance, and the first harvest 

● Major Event: Trials of Nirrek – Some cultures hold endurance-based contests to prove one's strength. 

● Regional Variation: The Whuaz Khanate begins Great Raids if a sign from the Eternal Sky is seen. 

## AUTUMN (Transition & Decay) 

5. Ardorcrest – The Burning Winds 

● Symbolism: Change, storms, and preparation for the cold 

● Major Event: The Stormwatch – Communities gather to predict and prepare for the coming winter. 

● Celestial Event: The Blood Moon – Some say it’s an omen of disaster, while the Argyles see it as a time of reflection. 

6. Brannot – The Dimming Sun 

● Symbolism: Final harvest, storing food, and darker days 

● Major Event: The Shadow’s Feast – A festival where people honor the dead with feasts and lanterns. 

● Regional Variation: The Gnorl Pirates begin their “Season of the Reaver”, where ships become vulnerable targets. WINTER (Death & Reflection) 

7. Ewholt – The Frozen Breath 

● Symbolism: Survival, hardship, and loss 

● Major Event: The Night of the Last Flame – Families gather around a single candle to remember those lost to the past year. 

● Celestial Event: The Black Sky – The darkest night of the year, when the stars seem to vanish. 

8. Gasork – The Dead Month 

● Symbolism: Absolute cold, spirits, and rebirth approaches 

● Major Event: The Hollow Procession – A silent march through cities, honoring ancestors and the trials of winter. 

● Regional Variation: Ospesh & Agadir hold a Relic Ceremony, showcasing sacred artifacts passed down through the ages. 

# WEEKDAYS OF VARDIN 

1. Moonsday – A day for reflection and lunar alignment rituals. 

2. Windsday – Traditionally seen as a day of travel and messages. 

3. Firesday – A day of passion, war, and major decisions. 

4. Tidesday – A day linked to the sea, trade, and transitions. 

5. Gloomsday – Considered unlucky; some avoid business deals or travel. 

6. Swordsday – A day for warriors, training, and honor-bound duels. 

7. Restday – A day of worship, feasting, and recovery. 

# MAJOR HOLIDAYS & CELESTIAL EVENTS 

● First Thaw Festival (Ciarrer 12th) – A day of dancing, song, and offerings for good fortune. 

● Crimson Tourney (Lonnun 28th - 30th) – Elite fighters from all over Vardin compete. 

● Shadow’s Feast (Brannot 15th - 17th) – Honoring the dead with feasts and whispered prayers. 

● Night of the Last Flame (Ewholt 33rd) – A solemn night of remembrance. 

● The Hollow Procession (Gasork 40th-42nd) – The final event before the year resets. COMMON FOLK BELIEFS & HOLIDAYS 

Not all follow strict religions—many common folk hold simpler spiritual traditions. 

● The Festival of Light (Nirrek 42nd) – People light lanterns and candles to ward off unseen evils and bring luck for the coming seasons. 

● The River’s Blessing (Tidesday of Ciarrer 21st) – Offerings of coins, flowers, and bread are cast into rivers for safe travels. 

● The Watcher’s Vigil (Gasork 40th) – Families place a single candle in their window to guide lost souls home. 

# Synthesis Technologies 

Flying ships -

Description: Large flying vessels powered by Synthesis-infused engines, these ships glide across the skies, allowing for fast travel between cities and regions. They are used by both military and civilian sectors, often carrying goods, people, and even soldiers for defensive missions. 

Features: 

● Engines fueled by crystallized magic that allow for controlled flight. 

● Defensive systems such as magical shields, anti-monster cannons, or Synthesis-powered turrets. 

● Luxurious cabins for nobility or business travel, using Synthesis for lighting, temperature control, and advanced comforts. 

Guns -

Description: Firearms powered by Synthesis technology, these weapons use magical energy as ammunition or as a means to amplify the damage caused by traditional projectiles. 

Features: 

● Energy bolts or magically-enhanced bullets that can pierce through even the toughest of creatures, including the Dwellers. 

● Energy shields that can block incoming projectiles, created from Synthesis energy stored in the gun. 

● Rechargeable power cells that make these firearms more efficient and less reliant on traditional ammunition. 

Artificial Lights and power -Description: Before the Slip, many civilizations relied on traditional sources of light like torches or lamps. After the Slip, Synthesis energy has revolutionized illumination. Cities now have Synthesis-powered lamps, streetlights, and generators, which operate without the need for oil or fire. 

Features: 

● Everlasting lights powered by Synthesis that never run out of fuel. 

● Energy stations that distribute magical power to the city or military base, keeping everything running—airships, weapons, and even personal devices. 

● Portable light sources , like lanterns or handheld lamps, powered by Synthesis crystals, which allow adventurers to explore caves or fight in darkness. 

Basic Automatons - Humanoid + Horse and Bird -

Description: Human-like or beast-like machines that can be used for a variety of purposes. Some act as workers in cities or as guards, while others are designed for combat. These automatons are powered by Synthesis crystals, making them incredibly durable and capable of advanced tasks. 

Features: 

● Combat automatons with advanced weaponry, using energy-infused weapons like blades or energy guns. 

● Labor automatons designed for construction, farming, or other heavy-duty tasks, which are key to rebuilding the world after the chaos of the Slip. 

● Self-repairing systems powered by Synthesis, allowing them to stay functional over long periods. 

Limited communication over distance -

Description: In a world still recovering from the chaos of the Slip, communication is crucial. These devices—powered by Synthesis—allow people to communicate over vast distances, whether between cities or between adventurers in the field. 

Features: 

● Crystal-powered communicators that allow for voice or even magical image transmission. 

● Relay stones used by armies or guilds to send messages and orders instantly across long distances. 

● Telepathic devices that use Synthesis to amplify thought transmission, allowing users to send short messages or alerts to allies in a dangerous area. 

Magi Armour -Description: Powered armor suits that enhance the wearer’s strength, speed, and durability. Often worn by elite soldiers, Argyles, or even royal guards, these suits use Synthesis-infused crystals to provide both physical protection and magical enhancements. 

Features: 

● Reinforced plating that protects against monster claws, teeth, and projectiles. 

● Mana-infused enhancements that allow for spells to be cast directly from the armor, such as shields, elemental blasts, or healing spells. 

● Enhanced mobility , allowing the wearer to jump higher, run faster, or withstand greater environmental stress (e.g., extreme heat or cold). 

Limited Healing Chambers -

Description: Medical technology powered by Synthesis that accelerates healing and regenerates tissue. These chambers are used by major cities or military forces to treat injured soldiers or civilians who have suffered from the Dwellers’ attacks. 

Features: 

● Healing fields generated by Synthesis that promote rapid tissue regeneration. 

● Energy-infused beds or pods that can heal broken bones, cure diseases, or even slow the progression of magical curses. 

● Diagnostic tools powered by Synthesis, allowing healers to identify issues and administer treatment more effectively. 

Weapons -

Description: Weaponry enhanced with Synthesis crystals that imbue ordinary weapons (swords, axes, spears) with magical properties. These can deal elemental damage or possess other enchantments that make them ideal for battling the Dwellers. 

Some Features: 

● Flame-infused blades that can cut through even the toughest monsters. 

● Electric spears or lightning-infused crossbows that stun or fry enemies. 

● Elemental stone-infused hammers , allowing the user to channel the power of earth, fire, or water in combat. 

# Religions The Commonwealth - The commonwealth believes in the 5 Celestials. 5 God like beings that took the likeness of a Dragon, originally believed to have hailed from an alternate dimension - they fled as it died. 

This dimension was at the time was empty and lifeless, so the Celestials used their power to created a new world to host them. 

Ayndrion - The First and youngest of the Dragons created the land. 

Ygaelth - The Second created the oceans, rivers and lakes. 

Etyss - The Third created the trees, and flowers. 

Zarenti - The Fourth created the mountains, valleys and caves. 

Iemydi - The Fifth and oldest of the five, created Fire, the basis for all life in the world. 

However despite all their power, the five could not create sentient life, and the world still remained empty no matter their efforts. So, after contemplating their problem, they reached a solution. Separating their magics and souls, they spread it over the land seeding life as we know it. 

Everything has a soul, a piece of the 5 that created the world. 

Republic of Oricia - A largely trading Nation, they prayed and worshiped the God of Water Uvian 

who they believe created all life in the world, although in more recent years the belief has died out -a great many still pray and pilgrimage to the Water Temple in the Capital City of Consentia. 

This religion also has a great hold in Ospesh , however this is more of a devotion to water itself rather than a single entity. 

Dwarves - The dwarves of Vardin revere The Unyielding Forge , a faith that views creation, endurance, and legacy as the highest virtues. To the dwarves, the world is a great anvil , and all living beings are metal shaped by struggle and time . It's creator, Eth enth withaur - Meaning the 'The One Before'. Who appeared in the world long before time. 

First creating the Land and Mountains of the world, and then the caves. Before forging the first Dwarf - Eth vulridir or The Father- in the fires of a volcano, modelled after his own image. He would teach 

Eth vulridir to wonders of creation, forging and building, who would then teach it to his own decedents. 

The World is the Great Forge: Existence is a constant test of resilience, and only those who endure hardship emerge stronger. 

Crafting is Sacred: A dwarf’s worth is measured not just in battle, but in what they leave behind—a smith’s blade, a stone fortress, or a well-told story. 

Synthesis is an Impure Metal: While some embrace it, many dwarves distrust Synthesis, believing it to be an unnatural force that skews the balance of the world. Whuzan Khanate - They worship the Horse God - Azarga , a mythical horse that pulls the stars and moons in place in the sky, ensuring that the world has a night and day - and his sons the Salkhi -which represent the Four Seasons, and guarantee the years and crops will last. 

Agadir Sultanate - Ilevisha is a new religion with one main god - Somos, and a hierarchy of minor gods called the Assembly. 

Their main teachings revolve around knowledge and belief, and these teachings are often passed on through community newsletters and studies of their religious works. 

Ilevisha's teachings come from a book translated several times written by all the gods as a direct reply to false gods and prophets spreading lies. The majority of their religious symbols are represented in the form of wood carvings, rings and bracelets. 

Being a new religion, Ilevisha is still a cohesive religion with a following with just a single interpretation of the religious works, . Ilevisha is often met with indifference by those outside of this religion. 

The elves of Vardin follow The Undying Thread , a faith that views existence as a vast, woven tapestry of fate, memory, and time. 

Elves believe that every living being is a thread in the grand Weave of Eternity , an ever-growing tapestry that records all life, choices, and history .

● Time is a Loom: The past, present, and future are interwoven. No thread truly vanishes—it is merely rewoven into new patterns. 

● Memories Are Sacred: Elves believe that forgetting a person is the only true death —as long as someone is remembered, their thread remains. 

● Dwellers Are a Tear in the Weave: The Slip is viewed as a rupture in reality , corrupting the Weave with unnatural forces. 

Unlike many faiths, The Undying Thread has no singular gods , only eternal forces that maintain the Weave. 

● The Eternal Weaver – A nameless entity that guides fate, neither benevolent nor cruel .Some believe it speaks through dreams and omens .

● The Severed Threads – Spirits of those who were forgotten or erased , lingering as lost echoes. Some say they whisper in the wind. 

● The Spindleborn – Elves who retain memories of past lives , believed to be old souls woven anew. 

# World Renowned Guilds 

# The Gilded Anvil (Master Crafters, Synthesis Smiths) A prestigious guild of artificers, blacksmiths, and inventors who create Synthesis-powered weapons and technology .

● Motto: "To shape the future, we must forge beyond limits." 

● Beliefs: Innovation over tradition —they push Synthesis technology to its limits, even at great risk. 

● Conflict: Hated by dwarven traditionalists and feared by governments who worry about 

Synthesis-based superweapons .

# The Silver Tongues (Spies, Information Brokers) 

A network of courtiers, diplomats, and spies who sell information to the highest bidder .

● Motto: "Knowledge is worth more than gold." 

● Beliefs: A well-placed secret can change a war faster than a thousand swords. 

● Conflict: They are both invaluable and dangerous —governments use them while trying to suppress them .

# The Veilwalkers (Mages, Occultists, Time-Seers) 

A guild of mystics and lost magic seekers who study the Slip and the mystical scars it left on Vardin. 

● Motto: "The past is not lost, only forgotten." 

● Beliefs: Some Seek to "stitch the Slip shut" , while others want to unlock its secrets for power .

● Conflict: Seen as heretics by religious groups and dangerous by those who fear the return of the Slip’s horrors .

# The Coinbound Pact (Mercenary Companies, Sell-Swords) 

A guild of mercenaries and warbands , bound by a strict contract system—once a deal is made, it 

cannot be broken .

● Motto: "Honor is measured in coin and steel." 

● Beliefs: They serve no king, only the contract —loyalty is bought and paid for .

● Conflict: Nations hate them for selling their swords to the highest bidder , but also rely on them for wars. 

# The Silent Archive (Historians, Relic Keepers) 

A secretive order dedicated to preserving lost knowledge , including pre-Slip magic, Synthesis lore, and ancient artifacts .

● Motto: "We guard what time seeks to erase." 

● Beliefs: Knowledge must be preserved, not exploited .

● Conflict: Opposed by governments that want control over history , and by treasure hunters 

who steal artifacts for profit.