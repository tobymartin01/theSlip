---
type: Monster
world: Vardin
campaign: The Slip
description: Larger clawed creature
race:
  - Dweller
size:
  - Large
threat:
  - High
---

### **Appearance:**  
The **Stalker** is the horrific end result of full corruption. Towering over most humanoids, it is **covered in patchwork flesh**, both human and beast - as if multiple entities were fused together in agony. It walks on **back-bent legs**, and its elongated arms drag sharp talons across the ground. A **maw splits its chest vertically**, filled with **needle-like teeth** that snap independently from its skull-mouth. Its body pulses and twitches with **dark fungal veins** or **arcane rot**, depending on its origin.

### **Behavior:**  
The Stalker is **intelligent enough to hunt**, waiting for the right moment to strike from shadow or high ground. Unlike the Hollow, it displays **cunning and malice**, often toying with prey or **separating them** before the kill. It emits **low, rumbling growls** and can move with terrifying speed despite its size. When cornered, it becomes berserk, lashing out in a flurry of bites, slashes, and bone-breaking grapples.

### **Notable Traits:**

- Can temporarily phase into shadow to reposition