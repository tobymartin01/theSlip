---
type: Monster
world: Vardin
campaign: The Slip
description: Smaller, clawed creature
race:
  - Dweller
size:
  - Medium
threat:
  - Low
  - Moderate
banner: "![[Compendium/Resources/Monsters/hollow.png]]"
banner-x: 51
banner-y: 17
---

*“Silent, sightless, and swift - They take what they cannot understand.”*


# **Appearance**

- Slouched, humanoid shape, rising up to 8ft when fully extended.
- Pale white to light grey skin, stretched tight across a thin, sinewy frame.
- Cheshire-like mouth of needle teeth; entirely eyeless.
- Long arms with three-digited hands and feet, built for grasping and climbing.    

# **Behavior**

- Hunts in small packs, highly coordinated and fast.
- Prefers ambush tactics, targeting isolated or distracted prey
- Often removes the eyes of victims - reason unknown, possibly instinctive.
- Reacts strongly to sudden movement or loud noises.   

# **Habitat**

- Caves, sewers, ruined cellars, or other low-light environments.
- Thrives in abandoned settlements and subterranean tunnels.  

# **Abilities / Threat Notes**

- Exceptional hearing and smell; rudimentary magical sense compensates for blindness.
- Extremely fast despite its lanky build; lethal when hunting in numbers.
- Vulnerable to bright light and noise disruption tactics

