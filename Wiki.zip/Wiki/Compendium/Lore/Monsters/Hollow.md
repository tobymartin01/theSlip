---
type: Monster
world: Vardin
campaign: The Slip
description: Smaller, clawed creature
race:
  - Dweller
size:
  - Medium
threat:
  - Low
  - Moderate
---

### **Appearance:**  
A **Hollow** appears as a once-human figure, now gaunt and twisted. Its flesh hangs loosely over protruding bones, **gray and flaking like ash**. Its eyes are vacant pits, glowing faintly with a **sickly green light**, and its limbs move with unnatural jerks and spasms. **Black ichor leaks** from open sores, and the creature constantly emits a **dry, whispering rasp** - the sound of fragmented thoughts struggling to escape.

### **Behavior:**  
Hollows **wander aimlessly** until drawn by noise, movement, or emotion - especially fear. In groups, they seem to move with eerie synchronisation, but **each one lacks will** or memory. They are **remnants**, corrupted by a failed transformation or a parasitic presence. They attack with **clawed hands** and sudden, frantic bursts of violence, often **screaming wordless fragments** of their past lives mid-attack.

### **Notable Traits:**
