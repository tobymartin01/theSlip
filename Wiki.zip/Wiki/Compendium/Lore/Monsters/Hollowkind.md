---
type: Monster
world: Vardin
campaign: The Slip
description: Once-humanoid figures now entirely wrapped in animate, tattered bandages that shift and coil of their own accord. Beneath the wrappings lies only darkness—no flesh, no bone, no form.
race:
  - Dweller
size:
  - Medium
threat:
  - Moderate
---
***Threat Class: Class II (Greater Dwellers)***

  

*"There is nothing beneath the wrappings,*

  

*Yet they watch as if they remember.*

  

**Appearance**

  

* Once-humanoid figures now entirely wrapped in animate, tattered bandages that shift and coil of their own accord. Beneath the wrappings lies only darkness—no flesh, no bone, no form.

* Their “faces” are marked by faint indentations where features should be, but never fully emerge.

  

**Behavior**

  

* Philosophers, observers, and sometimes experimenters.

* The Hollowkind claim to have lost their “selves” during the Slip and now study mortals in an effort to understand existence.

* They may record, question, or even subject individuals to strange “tests” without warning, often with no regard for morality.

  

**Habitat**

  

* Wander ancient libraries, ruined monasteries, or any place of learning.

* Frequently appear at moments of great historical significance, as though drawn to pivotal events.

  

**Abilities / Threat Notes**

  

* Animate wrappings can bind and restrain foes effortlessly.

* Capable of absorbing objects into the darkness beneath their coverings, seemingly storing them elsewhere.

* Generally non-hostile unless they deem your suffering necessary for their research.

* Diplomacy is possible, but never let curiosity be mistaken for trust.