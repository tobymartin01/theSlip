*"Alone, they are nothing.* *Together, they are an* *unstoppable tide of the forgotten."*

# **Appearance**

* Resembles a rotting, shambling humanoid corpse—skin discoloured, posture slack, and movements sluggish.
* Eyes are glazed or missing entirely.
* Many bear remnants of armour, tattered uniforms, or personal effects from their past life.  

# **Behavior**

* Alone, they are slow, clumsy, and easily dispatched. In groups, however, they become a relentless tide of grasping hands and gnashing teeth, overwhelming even trained fighters through sheer weight of numbers.
* Often drawn toward noise, movement, or lingering death.

# **Habitat**

* Gather in or near sites of mass death—abandoned battlefields, plague-ridden towns, and locations of great tragedy.
* Seem compelled to wander without purpose until prey enters their path.

# **Abilities / Threat Notes**

* Individually harmless but exponentially more dangerous in large groups.
* Immune to pain, unbothered by injury, and difficult to intimidate.
* Best countered with fire, chokepoints, and elevated positions to avoid encirclement