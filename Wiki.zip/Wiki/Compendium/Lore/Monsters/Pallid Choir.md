---
type: Monster
world: Vardin
campaign: The Slip
description: Gaunt, emaciated humanoids with skin stretched tight over bone.
race:
  - Dweller
size:
  - Medium
threat:
  - Low
---
***Threat Class: Class II (Greater Dwellers)***

  

*"Their song is the unmaking of the world."*

  

**Appearance**

  

* Gaunt, emaciated humanoids with skin stretched tight over bone.

* Their faces appear like smooth porcelain masks until they sing—then the surface splits into dozens of needle-toothed mouths, each producing its own note.

* Their bodies bear ritualistic markings, some etched into the skin, others burned into the flesh.

  

**Behavior**

  

* Travel in tightly-knit groups, moving with eerie synchronisation.

* Their harmonies alter both minds and matter—inducing madness, breaking Synthesis protections, and even warping the environment.

* Victims often experience uncontrollable weeping, violent impulses, or complete submission to the Choir’s will.

  

**Habitat**

  

* Remote ruins, abandoned temples, and places with naturally resonant acoustics.

* Often found near sites of historic bloodshed or failed religious rites.

  

**Abilities / Threat Notes**

  

* Reality-warping harmonies. Songs can compel obedience, erode mental stability, or shatter magical wards.

* Silence wards and distance are the only reliable defences.

* Never allow yourself to be surrounded; Choir formations amplify power exponentially.