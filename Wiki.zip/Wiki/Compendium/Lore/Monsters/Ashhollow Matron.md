---
type: Monster
world: Vardin
campaign: The Slip
description: An ancient, calcified giant lies curled beneath the sands, her form resembling a titan made of fossilised bone and cracked stone.
race:
  - Dweller
size:
  - Large
threat:
  - High
---
***Class III (Cataclysmic Dwellers) – Legendary or world-ending threats.***

  

| *404 Image not found :/* |

| :---- |

  

*"The desert is her cradle.*

  

*The bones are her lullaby."*

  

**Appearance**

  

* An ancient, calcified giant lies curled beneath the sands, her form resembling a titan made of fossilised bone and cracked stone.

* Her body is hollowed, the ribs and pelvis forming a vast cavernous nest filled with writhing Dweller spawn.

* When she stirs, the desert itself shifts with her, dunes rising and falling like ocean waves.

  

**Behavior**

  

* Normally dormant for centuries, the Ashhollow Matron awakens when disturbed by large-scale movement or excessive Slip corruption.

* Her shifting body triggers colossal sandstorms, and her wailing breath turns living tissue to brittle ash.

* She spawns swarms of insectoid, winged, or eyeless child-Dwellers to defend her resting place.

  

**Habitat**

  

* The deep desert wastes of the Agadir Sultanate, far from any settled oasis.

* Her presence is often preceded by days of whispering winds and faint vibrations through the dunes.

  

**Abilities / Threat Notes**

  

* Generates regional-scale sandstorms and seismic disruptions. Breath desiccates organic matter instantly. Spawn waves can overwhelm entire armies while she remains protected beneath the sands.

* Standard Argyle protocol: avoidance and long-range observation only—engagement is a death sentence.