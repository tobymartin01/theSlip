---
type: Monster
world: Vardin
campaign: The Slip
description: Shadowy, shimmering silhouettes that reflect the form of any nearby observer.
race:
  - Dweller
size:
  - Medium
threat:
  - Moderate
---
***Threat Class: Class II (Greater Dwellers)***

  

*"Stare long enough,*

  

*and it stares back*

  

**Appearance**

  

* Shadowy, shimmering silhouettes that reflect the form of any nearby observer.

* At first glance, they appear faceless and indistinct—until eye contact is made. In that instant, they perfectly replicate the target’s appearance, including clothing, voice, and even subtle mannerisms.

* Prolonged encounters result in their “reflection” becoming more detailed and disturbingly real.

  

**Behavior**

  

* Infiltrators and impostors, the Mirrorkind replace individuals over time by assuming their appearance and memories.

* They integrate seamlessly into communities, eroding trust and sowing paranoia.

* When exposed, they retreat only to resurface elsewhere under a new guise.

  

**Habitat**

  

* Often begin on the outskirts of settlements, adopting the guise of travellers or merchants before moving inward.

* Some operate alone, others in coordinated groups to replace entire households or leadership circles.

  

**Abilities / Threat Notes**

  

* Perfect physical and vocal duplication. Absorb memories through prolonged proximity, becoming almost indistinguishable from the original.

* The longer a Mirrorkind holds a form, the harder it is to separate them from their victim.

* Strong magical detection or Synthesis-based resonance checks are the most reliable means of identification.