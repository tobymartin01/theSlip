---
type: Monster
world: Vardin
campaign: The Slip
description: Tall, spindly humanoids with elongated limbs and featureless faces, their skin shifting like oil over water.
race:
  - Dweller
size:
  - Medium
threat:
  - Moderate
---
***Threat Class: Class II (Greater Dwellers)***

  

*"They do not hate you.*

  

*They do not love you.*

  

*They simply correct you."*

  

**Appearance**

  

* Tall, spindly humanoids with elongated limbs and featureless faces, their skin shifting like oil over water.

* Their movements are unnervingly smooth, with no wasted motion. They leave no footprints or scent, and their bodies seem to subtly warp light around them, as though rejecting the reality they inhabit.

  

**Behavior**

  

* Observers and “correctors” of perceived inconsistencies in the world.

* Vireliths spend long periods standing perfectly still, studying their surroundings, before abruptly moving to “adjust” people, objects, or environments in ways that align with their unknown code.

* These “adjustments” often prove fatal to living beings.

  

**Habitat**

  

* Not bound to any one location, but they manifest most often in areas with high magical instability or Slip-related anomalies.

* Known to appear near scholars, mages, or Argyles investigating dangerous Synthesis phenomena.

  

**Abilities / Threat Notes**

  

* Capable of erasing objects, creatures, or even sections of terrain from reality entirely.

* Move with impossible speed when executing an “adjustment.”

* Immune to emotional manipulation, illusions, and most magic.

* Avoid direct confrontation; their logic is alien and inflexible.