---
type: Monster
world: Vardin
campaign: The Slip
description: A titanic, blind worm whose segmented body is the size of a small mountain.
race:
  - Dweller
size:
  - Large
threat:
  - High
---
***Class III (Cataclysmic Dwellers) – Legendary or world-ending threats.***

  

*"The earth tolls your death."*

  

**Appearance**

  

* A titanic, blind worm whose segmented body is the size of a small mountain.

* Its hide is armored with cathedral-like plates fused with shards of bronze and iron bells, each tolling endlessly as it moves.

* The sound is not simply heard—it resonates through the bones and minds of all nearby.

  

**Behavior**

  

* Molgrath burrows through the earth with cataclysmic force, consuming towns, landscapes, and armies in its wake.

* The tolling of its embedded bells induces hallucinations, seizures, and madness in those exposed for too long.

* It rarely surfaces fully, instead emerging partially to feed before sinking back into the depths.

  

**Habitat**

  

* Deep subterranean networks far below known mines and caverns.

* Often emerges near seismic fault lines or in regions destabilised by Slip activity.

  

**Abilities / Threat Notes**

  

* Seismic tunnelling collapses terrain for miles around.

* Sonic resonance from its bells incapacitates both mind and body.

* No known weapon has ever slain Molgrath—best practice is immediate evacuation of the region.