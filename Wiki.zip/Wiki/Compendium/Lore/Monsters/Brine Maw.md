---
type: Monster
world: Vardin
campaign: The Slip
description: A colossal, eel-like predator with translucent, pale-blue skin stretched tight over thick muscle and cartilage.
race:
  - Dweller
size:
  - Large
threat:
  - Moderate
---
***Threat Class: Class II (Greater Dwellers)***

  

*"The wave breaks…*

  

*and the teeth follow.”*

  

**Appearance**

  

* A colossal, eel-like predator with translucent, pale-blue skin stretched tight over thick muscle and cartilage.

* Its head is crowned with barnacle-encrusted spines, and its gullet bristles with rows of backward-facing teeth designed to drag prey deeper into its body.

* Bioluminescent patterns flicker along its sides, shimmering in dark water.

  

**Behavior**

  

* Ambush predator that attacks from below, breaching the surface to snatch prey from docks, boats, or shoreline.

* Often hunts in small pods to overwhelm targets, ramming vessels before dragging them under.

* Once prey is seized, the Brine Maw retreats into deeper waters to consume it.

  

**Habitat**

  

* Coastal shallows, estuaries, and submerged Slip-rent trenches.

* Known to haunt shipwrecks and tidal straits with strong currents.

  

**Abilities / Threat Notes**

  

* Possesses a stunning electrical discharge capable of incapacitating prey in water. Teeth hook backward, making escape almost impossible.

* Can breach and destabilize small ships. Avoid swimming or anchoring in known Brine Maw hunting zones.