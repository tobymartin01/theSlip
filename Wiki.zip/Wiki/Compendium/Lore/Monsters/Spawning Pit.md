---
type: Monster
world: Vardin
campaign: The Slip
description: Pit that can spawn other monsters
race:
  - Dweller
size:
  - Large
threat:
  - Variable
banner: "![[Compendium/Resources/Monsters/pit.png]]"
banner-x: 49
banner-y: 41
---
 *"The ground here breathes, and the breath smells of hunger."*


# **Appearance**

- A gaping wound in the earth, often mistaken for a collapsed sinkhole or cave entrance. 
- The walls are coated with slick, black ichor, pulsating as if alive. Bones, half-dissolved corpses, and tangled root-like growths protrude from the interior. 
- In some pits, the walls appear to shift and ripple faintly in torchlight.    

# **Behavior**

- Spawning Pits are not predators themselves but serve as birthing or summoning sites for certain Dwellers. 
- Creatures crawl from their depths at irregular intervals, sometimes in small hunting packs, other times in swarms. 
- Pits are fiercely defended by their spawn for several miles in every direction.

# **Habitat**

- Found in swamps, ruined cities, deep forests, and coastal cliffs. It can also appear spontaneously after intense Slip corruption events.

# **Abilities / Threat Notes**

-  The type of Dweller spawned depends on the pit’s origin and the corruption saturating it.
- Known variants produce Hollows, Thornbrood, or aquatic horrors in tidal zones. 
- Approach with extreme caution—many Argyle patrols have vanished attempting to seal or destroy the
