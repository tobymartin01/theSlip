---
type: Monster
world: Vardin
campaign: The Slip
description: A griffin-sized carrion predator with parchment-thin, translucent flesh stretched over wiry muscle and visible, twitching organs.
race:
  - Dweller
size:
  - Medium
threat:
  - Low
---
***Threat Class: Class I (Lesser Dwellers)***

  

*"The sky itself peels where it flies."*

  

**Appearance**

  

* A griffin-sized carrion predator with parchment-thin, translucent flesh stretched over wiry muscle and visible, twitching organs.

* Its face is a grotesque beak of exposed bone bound with barbed tendons, constantly opening in a soundless laugh—until it screams.

* Wings are ragged yet powerful, capable of violent bursts of speed.

  

**Behavior**

  

* Hunts in mated pairs, circling high above battlefields or coastal cliffs.

* Uses its eerie, flute-like screech to disorient prey—both human and animal—before diving in swift, savage attacks. Prefers to wound and harry prey into exhaustion before landing the killing blow.

  

**Habitat**

  

* Coastal cliffs of Oricia and Aplaria, as well as open skies over carrion-rich plains.

* Often follows migrating herds or military campaigns to feed on the dead.

  

**Abilities / Threat Notes**

  

* Sonic screech disrupts balance and temporarily deafens victims. Talons are coated in a neurotoxic ichor that induces weakness and blurred vision.

* Feeds not just on flesh, but on the mental impressions of the dying, leaving survivors haunted by vivid nightmares.