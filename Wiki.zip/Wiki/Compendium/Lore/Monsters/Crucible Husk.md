---
type: Monster
world: Vardin
campaign: The Slip
description: A hulking, golem-like figure formed from scorched stone, rusted armor, and charred bone, with molten veins glowing beneath cracked surfaces.
race:
  - Dweller
size:
  - Medium
threat:
  - Low
---
***Threat Class: Class I (Lesser Dwellers)***

  

*"Where the forge fails,*

  

*it walks."*

  

**Appearance**

  

* A hulking, golem-like figure formed from scorched stone, rusted armor, and charred bone, with molten veins glowing beneath cracked surfaces.

* Its movements are slow and deliberate, as though imitating the memory of battle stances long forgotten.

* When still, it can be mistaken for a broken statue or forge remnant.

  

**Behavior**

  

* Drawn to sources of heat and metal, Crucible

* Husks wander aimlessly until they encounter prey or valuable materials.

* They attack with brutal, crushing blows, often using their own superheated bodies as weapons.

* Some remain dormant for decades until awoken by disturbance.

  

**Habitat**

  

* Frequently found in the mountains of Sceca, particularly near collapsed forges, ruined mining towns, or ancient battlefield relics.

* Clusters of them can sometimes be found in abandoned industrial sites where Slip corruption has fused metal and stone.

  

**Abilities / Threat Notes**

  

* Extremely durable, resistant to conventional weaponry.

* It can absorb fire and release it in explosive shockwave bursts.

* Contact with its body causes severe burns.

* Avoid prolonged engagements—strike from a distance or lure into terrain where its bulk becomes a liability.