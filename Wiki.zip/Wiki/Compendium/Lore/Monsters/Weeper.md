---
type: Monster
world: Vardin
campaign: The Slip
description: Grotesque, flayed humanoid with strips of hanging flesh. Moves with eerie, silent grace.
race:
  - Dweller
size:
  - Medium
threat:
  - Low
banner: "![[Compendium/Resources/Monsters/Weeper.png]]"
banner-x: 50
banner-y: 11
---


*“Its cries are a warning. Ignore them, or you’ll join the wail.”*

# **Appearance**

- Grotesque, flayed humanoid with strips of hanging flesh. Moves with eerie, silent grace.

# **Behavior**

- Lures victims with sorrowful cries. Often works in tandem with Stalkers, ambushing prey and dragging them into darkness.

# **Habitat**

- Urban slums, alleys, and abandoned districts.

# **Abilities / Threat Notes**

- Deadly ambush predator. Emotional lure through sound. Vulnerable if confronted in open light