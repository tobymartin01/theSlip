---
type: Monster
world: Vardin
campaign: The Slip
description: A massive predatory bird with a wingspan nearing 20 feet.
race:
  - Dweller
size:
  - Medium
threat:
  - Low
---
***Threat Class: Class I (Lesser Dwellers)***

  

*"You never see the Shrike coming \-*

  

*just the shadow,*

  

*the scream, and then the silence."*

  

**Appearance**

  

* A massive predatory bird with a wingspan nearing 20 feet.

* Jet-black feathers streaked with deep crimson along the wing edges, resembling fresh blood.

* Its hooked beak is sharp enough to tear through flesh and bone, and its talons are long, curved, and capable of piercing armor or stone.

* Eyes glow with an unnatural red light, constantly scanning for prey.

  

**Behavior**

  

* An apex aerial predator, the Shrike attacks from above with surgical precision, often striking without warning and vanishing back into the clouds.

* Its screech is both a hunting cry and a weapon, sending fear and panic through those who hear it.

* Known to attack lone travelers, isolated groups, or exposed positions.

  

**Habitat**

  

* Can appear anywhere but prefers high, open skies where it can dive from great heights. Commonly spotted above mountain ranges, coastal cliffs, or in storm-heavy skies.

  

**Abilities / Threat Notes:**

  

* Capable of incredible diving speeds, using momentum to crush and kill prey instantly.

* Talons can penetrate most known armor.

* Its screech can disorient or panic prey before an attack.

* Rare but extremely dangerous—watch the skies for shifting shadow