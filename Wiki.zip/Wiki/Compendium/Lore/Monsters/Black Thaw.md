---
type: Monster
world: Vardin
campaign: The Slip
description: A slick, tar-like ooze that falls as rain during storms in areas where reality has grown thin from Slip corruption.
race:
  - Dweller
size:
  - Medium
threat:
  - Low
---
***Threat Class: Class I (Lesser Dwellers)***

  

*"It doesn’t burn—*

  

*it melts you inward."*

  

**Appearance**

  

* A slick, tar-like ooze that falls as rain during storms in areas where reality has grown thin from Slip corruption.

* It clings unnaturally to surfaces, glistening with an oily sheen, and often moves against the pull of gravity in slow, unsettling motions.

  

**Behavior**

  

* Black Thaw doesn’t simply consume flesh—it erases identity, history, and memory.

* Victims who come into contact with it dissolve both physically and metaphysically, vanishing from the minds of those who knew them.

* The ooze seems drawn to movement and heat, but its patterns are unpredictable.

  

**Habitat**

  

* Appears in “broken regions” where the boundary between realms is unstable—shattered landscapes, areas with chronic magical failure, or sites of massive Dweller incursions.

* Always heralded by dark, heavy clouds and unnatural stillness before rainfall.

  

**Abilities / Threat Notes**

  

* Consumption by Black Thaw leaves no physical remains, and all records—written or otherwise—fade as if the victim never existed.

* Only Synthesis-inscribed tablets retain memory of the lost.

* Survivors may experience dreams of someone they almost remember but cannot name.

* Avoid exposed travel during a suspicious story