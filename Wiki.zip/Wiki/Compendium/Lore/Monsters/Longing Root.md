---
type: Monster
world: Vardin
campaign: The Slip
description: A partially intangible parasitic organism that exists between the dream and waking worlds.
race:
  - Dweller
size:
  - Medium
threat:
  - Low
---
***Threat Class: Class I (Lesser Dwellers)***

  

*"Don’t sleep where the dreams are soft.*

  

*That’s where it grows."*

  

**Appearance**

  

* A partially intangible parasitic organism that exists between the dream and waking worlds.

* In reality, it manifests as pale, fibrous roots pushing up through floors, stone, and soil. In dreams, it appears as warm, comforting visions—beloved faces, childhood homes, or places of deep nostalgia.

  

**Behavior**

  

* Feeds on sleeping prey by luring them into dreamscapes so vivid they resist waking.

* While the victim dreams, roots creep upward, piercing flesh and bone, drawing sustenance from the body.

* Victims often remain blissfully unaware until it is too late, waking only when half-consumed.

  

**Habitat**

  

* It can occur anywhere that Slip corruption has soaked into the earth. Found in abandoned homes, forgotten waystations, and even beneath occupied dwellings, given enough time.

  

**Abilities / Threat Notes**

  

* Dream lure is nearly impossible to resist without mental training or protective wards.

* Can be detected by trained Argyles via unnatural warmth in a room or the scent of flowers that do not exist.

* Once rooted, removal is difficult and dangerous, as severing the dream connection can kill the victim outright