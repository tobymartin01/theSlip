---
type: Monster
world: Vardin
campaign: The Slip
description: Humanoid figures whose cracked, obsidian-like skin glows faintly from the burning embers beneath.
race:
  - Dweller
size:
  - Medium
threat:
  - Moderate
---
***Threat Class: Class II (Greater Dwellers)***

*"From ruin, they learned peace.* *But their peace may be our undoing."*
# **Appearance**

* Humanoid figures whose cracked, obsidian-like skin glows faintly from the burning embers beneath.
* Wisps of smoke rise from fissures along their bodies, and their eyes burn like dying stars—dim yet ancient.
* Their clothing is often ragged but adorned with symbols or trinkets from realms long lost.

# **Behavior**

* The Ashen are refugees from a realm consumed during the Slip.
* They wander in small groups, offering wisdom, trade, or forbidden arcane secrets in exchange for sanctuary.
* While many are sincere in their desire for peace, others believe that sacrificing Vardin—or large portions of it—is necessary to create a new home.
* They avoid unnecessary conflict, but when provoked, their retaliation is swift and devastating.

# **Habitat**

* Hidden enclaves in remote valleys, forgotten cities, or deep mountain hollows.
* They often appear in areas of recent disaster, seemingly drawn to suffering and loss.

# **Abilities / Threat Notes**

* Possess powerful fire and earth-based magic tied to their former world.
* Capable of melting stone, shaping molten glass, and summoning choking ash storms.
* Immune to heat and flame.
* Diplomacy is possible, but betrayal or hostility will be met with annihilating force.