---
type: Monster
world: Vardin
campaign: The Slip
description: " Invisible to the naked eye, its presence is only betrayed through warped reflections, faint ripples in the air, or distortion in sound."
race:
  - Dweller
size:
  - Medium
threat:
  - Low
---
***Threat Class: Class I (Lesser Dwellers)***

  

*"Don’t speak where it fell.*

  

*It remembers your voice."*

  

**Appearance**

  

* Invisible to the naked eye, its presence is only betrayed through warped reflections, faint ripples in the air, or distortion in sound.

* In rare moments of partial manifestation, it appears as a twisting funnel of shimmering air and shadow, rotating slowly as if underwater.

  

**Behavior**

  

* An acoustic predator that mimics any sound it hears, from environmental noises to perfect imitations of human voices—including the dead.

* It uses these mimicries to lure victims into ambush zones, abandoned structures, or unstable terrain.

* The closer one comes, the more accurately it reproduces the target’s voice.

  

**Habitat**

  

* Most often found haunting the ruins of cities, temples, and battlefields, especially where echoes naturally linger.

* Known to follow travellers for miles if they make noise near its lair.

  

**Abilities / Threat Notes**

  

* Impossible to detect visually without reflective surfaces. Can perfectly mimic voices and sounds, exploiting emotional responses or trust.

* Killing one requires absolute silence over a wide area, often enforced with rituals or Synthesis barriers.

* Argyles recommend mirrored wards and muting charms when operating in known Echo-Whorl territory