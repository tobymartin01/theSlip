---
type: Monster
world: Vardin
campaign: The Slip
description: Cocooned, larva-like entities encased in translucent crystal shells, each the size of a person.
race:
  - Dweller
size:
  - Medium
threat:
  - Moderate
---
***Threat Class: Class II (Greater Dwellers)***

  

*"Some cocoons open to beauty.*

  

*Others to bondage.”*

  

**Appearance**

  

* Cocooned, larva-like entities encased in translucent crystal shells, each the size of a person.

* In daylight, the shells are opaque and inert.

* Under moonlight, the crystal becomes clear, revealing their true forms—gossamer-winged, luminous beings of haunting beauty, their skin shimmering with shifting colors.

  

**Behavior**

  

* Draw in those who are lost, broken, or yearning for purpose.

* The Chrysalites offer healing, companionship, or “transformation” through an emotional bond.

* Some bonds are nurturing and beneficial; others are parasitic, slowly replacing the host’s will with their own.

* Groups of bonded humans have been known to act in eerie unison.

  

**Habitat**

  

* Secluded ruins deep within ancient forests, especially in areas rich with moonlight exposure.

* Known to emerge from hiding only during specific lunar phases.

  

**Abilities / Threat Notes**

  

* Empathic projection—can share emotions and vivid mental imagery directly into the minds of others.

* Flight and limited glamour magic under moonlight.

* The nature of the bond they form is unpredictable; once made, severing it can have devastating psychological effects.