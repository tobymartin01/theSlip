---
type: Monster
world: Vardin
campaign: The Slip
description: " A massive, boar-like beast the size of an ogre, with armor plates fused directly into its thick hide."
race:
  - Dweller
size:
  - Medium
threat:
  - Low
---
***Threat Class: Class I (Lesser Dwellers)***

  

*"Rot has tusks now."*

  

**Appearance**

  

* A massive, boar-like beast the size of an ogre, with armor plates fused directly into its thick hide.

* Its tusks are twisted amalgamations of warped bone and embedded fragments of rusted metal.

* Eyes are mismatched—one milky and blind, the other weeping blood—and its body constantly drips with foul ichor that stains the ground.

  

**Behavior**

  

* Blight-Tusks charge directly into opponents, crushing and goring anything in their path.

* They are territorial and will attack without provocation, especially when guarding feeding grounds.

* Wounds from their tusks or ichor often lead to rapid necrosis.

  

**Habitat**

  

* Dense, untamed forests along the Aplaria–Florian border, particularly in regions already suffering from rot or fungal spread.

* Often found where vegetation has inexplicably died in large patches.

  

**Abilities / Threat Notes**

  

* Can plough through dense terrain like a siege ram.

* Emits clouds of spores that weaken and slow organic targets over time. Immune to pain—will continue fighting despite catastrophic injury.

* Fire is effective, but risks spreading its spores on heated winds