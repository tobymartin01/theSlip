---
type: Monster
world: Vardin
campaign: The Slip
description: A vast, shifting “island” of black stone and coral that floats aimlessly across open seas. As ships approach, the surface begins to sink, revealing an immense, jaw-lined abyss ringed with bioluminescent tendrils.
race:
  - Dweller
size:
  - Large
threat:
  - High
---
***Class III (Cataclysmic Dwellers) – Legendary or world-ending threats.***

  

*"It does not drown you.*

  

*It erases you."*

  

**Appearance**

  

* A vast, shifting “island” of black stone and coral that floats aimlessly across open seas. As ships approach, the surface begins to sink, revealing an immense, jaw-lined abyss ringed with bioluminescent tendrils.

* The maw itself is large enough to swallow a port in a single bite, lined with serrated ridges that close like a colossal shell.

  

**Behavior**

  

* Thal’Zul lures prey with false lights in its tendrils, mimicking distant lanterns or shoreline beacons.

* Once within range, it creates massive whirlpools to draw vessels into its mouth.

* Any living beings taken within are never seen again, and even their existence fades from memory over time, as though they had never lived.

  

**Habitat**

  

* The deepest, least-travelled waters of Oricia’s Reach and beyond.

* Rare sightings have been reported in oceanic trade routes—always followed by the disappearance of vessels and their crews.

  

**Abilities / Threat Notes**

  

* It can silence all sound for miles, creating an oppressive auditory void.

* Alters sea currents and weather, causing storms to form around it like a crown.

* No known weapon has pierced its hide.

* Avoidance is the only survival—change course at the first sign of unnatural stillness or phantom lights.