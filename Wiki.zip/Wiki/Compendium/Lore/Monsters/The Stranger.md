---
type: Monster
world: Vardin
campaign: The Slip
description: Semi-corporeal silhouette resembling a man with faint purple eyes.
race:
  - Dweller
size:
  - Medium
threat:
  - Low
banner: "![[Compendium/Resources/Monsters/theStranger.png]]"
banner-height: 440
banner-radius: 30
content-start: 371
banner-fade: -30
banner-x: 50
banner-y: 11
---

*“It wears the faces of the dead, and lures you with the comfort of the familiar -until it’s too late.”*


# **Appearance**

- Semi-corporeal silhouette resembling a man with faint purple eyes.
- True form unknown; always mimics faces of those the victim knows.    

# **Behavior**

- Mimics familiar voices or appearances to lure prey into traps or ambushes.
- Kills by strangulation or environmental hazards (falls, swamps, pits).  Light is physically painful—flees or becomes hostile when exposed.    

# **Habitat**

- Remote, dark, and isolated places; forests, ruins, abandoned homes.

# **Abilities / Threat Notes**

- Psychological predator; thrives on fear and deception.
- Capable of perfect mimicry after brief observation.
- Weak to light and group tactics; never seen in populated region