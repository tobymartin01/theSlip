---
type: Monster
world: Vardin
campaign: The Slip
description: A faceless humanoid titan of grotesque proportions, its bloated, sagging flesh split in places to reveal writhing, infected tissue beneath.
race:
  - Dweller
size:
  - Large
threat:
  - High
---
***Class III (Cataclysmic Dwellers) – Legendary or world-ending threats.***

  

*"It does not bring salvation—*

  

*only the slow rot of all it touches."*

  

**Appearance**

  

* A faceless humanoid titan of grotesque proportions, its bloated, sagging flesh split in places to reveal writhing, infected tissue beneath.

* Multiple arms—some dragging along the ground, others reaching—protrude from its torso at unnatural angles.

* Thick, yellowish pus weeps constantly from its body, steaming where it touches the earth.

  

**Behavior**

  

* Moves at an agonizingly slow pace, yet nothing in its path survives.

* The pus it exudes corrodes flesh, bone, and metal, and reanimates corpses into shambling extensions of its will.

* The God That Crawls does not appear to think or speak—its progress is simply a tide of plague and decay, leaving wasteland in its wake.

  

**Habitat**

  

* Appears in heavily corrupted wastelands, abandoned plague cities, or battlefield graveyards.

* Its arrival is often preceded by weeks of spreading disease and unnatural stillness in wildlife.

  

**Abilities / Threat Notes**

  

* Acidic secretions melt armour and flesh, and the reanimated dead spread infection further.

* Resistant to most physical weapons—fire can slow i,t but not stop it. Avoid engagement entirely; containment and evacuation are the only recommended responses.