---
type: Monster
world: Vardin
campaign: The Slip
description: Humanoid in shape but unsettlingly incomplete—often missing key features such as eyes, mouths, or even shadows.
race:
  - Dweller
size:
  - Medium
threat:
  - Moderate
---
***Threat Class: Class II (Greater Dwellers)***

  

*"They are the quiet between heartbeats—*

  

*the pause that swallows magic whole."*

  

**Appearance**

  

* Humanoid in shape but unsettlingly incomplete—often missing key features such as eyes, mouths, or even shadows.

* Their skin is pale and matte, seeming to absorb light rather than reflect it.

* The air around them is unnaturally still, as if sound itself hesitates to exist in their presence.

  

**Behavior**

  

* The Nullborn are anti-magic entities, appearing in places of unstable Synthesis or chaotic arcane activity.

* They methodically dismantle magical effects, artifacts, and even living beings suffused with magic.

* Though not openly aggressive without provocation, they will destroy anything they deem “unsafe” or “unreal.”

  

**Habitat**

  

* Slip-saturated ruins, sites of magical disasters, or regions plagued by Dweller corruption.

* Occasionally wander into inhabited areas suffering from magical instability, where they may be tolerated—warily—for their cleansing effect.

  

**Abilities / Threat Notes**

  

* Their very presence dampens and disrupts magic, rendering spells weaker or null.

* Can unravel enchantments or destroy Synthesis technology simply by touch. Operate with absolute, cold logic—incapable of lying but also devoid of compassion.

* Considered both saviours and threats depending on circumstances