---
type: Monster
world: Vardin
campaign: The Slip
description: Sleek, scaled predators resembling elongated fish with jagged dorsal fins and three black eyes on each side of the head.
race:
  - Dweller
size:
  - Medium
threat:
  - Low
---
***Threat Class: Class I (Lesser Dwellers)***

  

*"A flicker in the tide,*

  

*a shadow in the shallows."*

  

**Appearance**

  

* Sleek, scaled predators resembling elongated fish with jagged dorsal fins and three black eyes on each side of the head.

* Fins and tails glimmer faintly, refracting light unnaturally.

  

**Behavior**

  

* Hunt in small packs, darting in to bite and retreat before prey can respond.

* Extremely curious, sometimes following swimmers for hours before striking.

  

**Habitat**

  

* Reefs, tidal rivers, and shallow surf zones. Known to venture into flooded streets during storms.

  

**Abilities / Threat Notes**

  

* Razor-sharp teeth can tear through leather and cloth in seconds. Agile and difficult to hit in the water.

* Vulnerable when beached, but quick to return to the tide.