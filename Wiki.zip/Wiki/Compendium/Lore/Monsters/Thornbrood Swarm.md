---
type: Monster
world: Vardin
campaign: The Slip
description: " Needle-thin arthropods made of translucent chitin interlaced with black, wire-like veins."
race:
  - Dweller
size:
  - Medium
threat:
  - Low
---
***Threat Class: Class I (Lesser Dwellers)***

  

*"One is nothing.*

  

*A thousand is a feast."*

  

**Appearance**

  

* Needle-thin arthropods made of translucent chitin interlaced with black, wire-like veins.

* Each individual resembles a living splinter, no longer than a finger, with hooked mandibles and multiple jointed legs.

* When swarming, they form spiralling, cloud-like masses that shimmer and buzz with an electric, static-like hum.

  

**Behaviour**

  

* Act with hive-mind coordination, moving in fluid patterns to encircle and overwhelm prey.

* Swarms strip flesh from bone within seconds, then move on to the next target.

* Infected corpses may serve as breeding grounds, erupting hours later into fresh swarms.

  

**Habitat**

  

* Primarily found in the marshes of eastern Tylia, though migrating clouds have been reported far inland after storms or large-scale battles.

  

**Abilities / Threat Notes**

  

* Incredible collective speed and agility.

* Can merge into larger hybrid forms such as humanoid centipedes or lumbering cocoons of fused bodies.

* Vulnerable to fire, strong winds, and corrosive agents.

* Do not engage without protective gear—single Thornbrood bites are painful, but swarms are lethal in seconds