---
type: Monster
world: Vardin
campaign: The Slip
description: Pale, bloated humanoid figures suspended beneath the surface, their limbs swaying as if in a slow dance.
race:
  - Dweller
size:
  - Medium
threat:
  - Moderate
---
***Threat Class: Class II (Greater Dwellers)***

  

*"Their song pulls you down,*

  

*and the water keeps you there."*

  

**Appearance**

  

* Pale, bloated humanoid figures suspended beneath the surface, their limbs swaying as if in a slow dance.

* Their faces are frozen in silent screams until they begin to sing, revealing mouths full of blackened teeth.

* Faint blue light emanates from their eyes and throats in time with their melody.

  

**Behavior**

  

* Operate in coordinated groups, circling vessels or lone swimmers.

* Their harmonics disorient the listener, inducing dizziness, nausea, and eventually unconsciousness.

* Victims sink beneath the surface and are carried to the depths for feeding.

  

**Habitat**

  

* Deep lakes, fog-bound harbors, and coastal waters during periods of stillness. Often appear in areas where ships or entire crews have vanished.

  

**Abilities / Threat Notes**

  

* Their song bypasses most forms of sound-blocking protection, resonating directly in the inner ear.

* Once entranced, resisting the pull is nearly impossible without external intervention.

* Killing one disrupts the harmony but does not stop the attack if others remain.