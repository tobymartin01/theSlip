---
type: Monster
world: Vardin
campaign: The Slip
description: Its form shifts with the observer—some see a towering knight clad in fractured glass armour, others a roiling storm, or a spider of glistening crystal limbs.
race:
  - Dweller
size:
  - Medium
threat:
  - High
---
***Class III (Cataclysmic Dwellers) – Legendary or world-ending threats.***

  

*"It is not in one place—*

  

*It is in every place you can see it."*

  

**Appearance**

  

* Its form shifts with the observer—some see a towering knight clad in fractured glass armour, others a roiling storm, or a spider of glistening crystal limbs.

* Regardless of the guise, all agree that reality bends and flickers around it: straight lines warp, colours invert, and time itself stutters.

* The air around it tastes of copper and ozone.

  

**Behavior**

  

* Veilwretchers hunt sources of great magical power or those who seek to unravel the mysteries of the Slip.

* They appear without warning, distort the flow of time, and dismantle Synthesis technology in their vicinity.

* Victims often report missing minutes—or days—after an encounter, with no memory of what transpired in between.

  

**Habitat**

  

* Not bound to a location; appears wherever Slip research or unstable Synthesis experiments occur.

* Some sightings suggest it can cross between multiple versions of Vardin at will.

  

**Abilities / Threat Notes**

  

* Causes localised time dilation, Synthesis disruption, and spatial distortion. Conventional attacks have little effect.

* Avoid direct observation for prolonged periods—prolonged exposure can induce reality bleed, where the victim partially exists in multiple places at once.