---
type: Monster
world: Vardin
campaign: The Slip
description: A monstrous, twisted entity with no defined shape, its form a sinuous mass of shadow and writhing tendrils.
race:
  - Dweller
size:
  - Medium
threat:
  - Low
---
***Threat Class: Class I (Lesser Dwellers)***

  

*"It doesn’t hunt you \-*

  

*It waits. And when it moves,*

  

*all that’s left is shadow and silence."*

  

**Appearance**

  

* A monstrous, twisted entity with no defined shape, its form a sinuous mass of shadow and writhing tendrils.

* Composed mostly of thick, inky blackness that shifts between solidity and smoke-like intangibility.

* No distinct limbs or head, only shifting appendages tipped with razor-sharp claws.

* At its centre are two sickly green, malevolent eyes surrounded by shifting shadow, making its “face” impossible to define.

  

**Behavior**

  

* An unnervingly patient predator, often stalking prey for days or even weeks before striking.

* It blends perfectly with deep shadows, moving silently until the moment of attack.

* Victims often feel an oppressive chill and unnatural stillness before it emerges. Known for its relentless pursuit once it commits to a target.

  

**Habitat**

  

* Rarely encountered but can appear anywhere.

* Most commonly found in areas of deep darkness—caves, abandoned structures, unlit streets, or open wilderness during moonless nights.

  

**Abilities / Threat Notes**

  

* Master of stealth and ambush. Can seamlessly blend into shadows, becoming nearly invisible.

* Tendrils can extend for sudden strikes, and claws cut through armour with ease. Its presence distorts air temperature and muffles sound, making it difficult to detect until it’s too late.

* Avoid traveling alone in unlit or enclosed spaces.