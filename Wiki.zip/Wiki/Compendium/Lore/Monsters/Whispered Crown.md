---
type: Monster
world: Vardin
campaign: The Slip
description: " A black, jagged circlet of bone and writhing tendrils, small enough to rest atop a human skull yet heavy with a palpable, oppressive presence."
race:
  - Dweller
size:
  - Medium
threat:
  - Moderate
---
***Threat Class: Class II (Greater Dwellers)***

  

*"Bow your head,*

  

*and you’ll never raise it again."*

  

**Appearance**

  

* A black, jagged circlet of bone and writhing tendrils, small enough to rest atop a human skull yet heavy with a palpable, oppressive presence.

* When attached to a host, the tendrils burrow into the scalp and spine, fusing the Crown to flesh and bone.

* Hosts’ eyes often glow faintly with a sickly, unnatural light, and their voices take on an echoing resonance.

  

**Behavior**

  

* The Whispered Crown enslaves its host’s will, turning them into charismatic leaders, prophets, or tyrants.

* It manipulates their speech, gestures, and decisions to gather followers.

* Feeds on obedience and belief, growing more potent as its cult expands. When a host dies, the Crown detaches and seeks a new vessel.

  

**Habitat**

  

* Rarely found without a host. Known to pass between warlords, clergy, and ambitious politicians.

* Relics recovered from Slip-saturated ruins may carry dormant Crowns.

  

**Abilities / Threat Notes**

  

* Dominates the host’s mind while enhancing their physical resilience.

* Can communicate telepathically to enthral others at a distance.

* The longer the bond, the harder it is to remove without killing the host.

* Destroying the Crown is possible but often fatal to the wear