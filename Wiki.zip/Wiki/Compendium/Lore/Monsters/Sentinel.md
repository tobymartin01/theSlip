---
type: Monster
world: Vardin
campaign: The Slip
description: Automaton warrior, usually set to protect an area of interest
race:
  - Construct
size:
  - Medium
  - Large
threat:
  - Variable
---

### **Appearance:**  
The **Automaton Sentinel** stands as a gleaming symbol of arcano-mechanical craftsmanship. Constructed from **reinforced alloy plates**, **brass joints**, and **arcane conduits**, its body hums with latent magical energy. Its **head is featureless**, save for a **central glowing ocular crystal**, often colored to indicate function or mood (red for combat, blue for patrol, etc.). When at rest, it stands motionless like a statue; when activated, its movements are **smooth, precise, and utterly silent**, save for the soft hum of power cores and servos.

### **Behavior:**  
Automaton Sentinels are **tireless guardians**, designed to **patrol, observe, and respond** to intrusions or threats. Unlike mindless constructs, higher-tier models possess **limited tactical reasoning**, able to **prioritize targets, predict movement**, and **coordinate with other sentinels or living guards**. They follow strict protocols but can adapt if granted expanded directive permissions.

Most are **loyal to specific factions or guilds**, with internal sigils or emblems embedded beneath plating to denote ownership. Unauthorized tampering with a sentinel is a capital offense in most city-states.

### **Capabilities:**

- Equipped with **telescopic visual sensors**, capable of seeing in complete darkness and through moderate illusion spells.
    
- Arms can transform into various tools or weapons — **arcane-blades, energy lances, or concussion gauntlets**.
    
- Can emit **a high-frequency alarm pulse** to alert nearby allies or deactivate lower-tier constructs.
    
- Powered by **modular crystal cores**, allowing tailored behaviors or battlefield roles (scout, brawler, crowd control).
    

### **Notable Traits:**

- Immune to poison, disease, and psychic damage
    
- Resistant to lightning and non-magical piercing weapons
    
- Can enter **sentinel mode**, becoming immobile but gaining advantage on perception checks and auto-detecting invisible creatures within 10 feet
    
- If critically damaged, some models **self-destruct**, releasing a concussive energy burst