---
type: Monster
world: Vardin
campaign: The Slip
description: Wraithlike beings draped in translucent, flowing shrouds that trail mist behind them.
race:
  - Dweller
size:
  - Medium
threat:
  - Moderate
---
***Threat Class: Class II (Greater Dwellers)***

  

*"Their tears heal, or they burn—*

  

*But they always fall for the suffering**"***

  

**Appearance**

  

* Wraithlike beings draped in translucent, flowing shrouds that trail mist behind them.

* Their faces appear carved from frozen tears—smooth, glistening surfaces constantly shedding droplets of liquid.

* These tears glow faintly and fall without ever depleting the “mask” that forms their visage.

  

**Behavior**

  

* Drawn inexorably to pain, tragedy, and despair.

* The Lacrimen do not speak, instead communicating by projecting vivid emotional memories directly into the minds of those they encounter.

* While they often comfort the dying or aid the wounded, they can also perform “mercy killings” without consent, believing it to be an act of compassion.

  

**Habitat**

  

* Commonly appear on battlefields after the fighting has ceased, at the bedsides of the mortally ill, or in the aftermath of natural disasters. Seem to avoid large, healthy crowds unless tragedy is imminent.

  

**Abilities / Threat Notes**

  

* Their tears have dual effects—healing wounds and soothing pain in some cases, or burning like acid in others.

* Capable of inducing overwhelming empathy or despair in targets, sometimes leading to paralysis or surrender.

* Not inherently hostile, but their perception of mercy may conflict fatally with human notions of life and survival.