---
type: NPC
faction: Archeologist Guild
location: Arcabourne
world: Vardin
campaign: The Slip
description: Member of the Archeologist Guild
race:
  - Human
gender: Male
class:
---
Member of the Archeologist guild who we understood to have information on how to sneak into the underground levels of the guild building. Has a fondness for sweet alcohol