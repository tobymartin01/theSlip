---
type: NPC
faction: 
location: Arcabourne
world: Vardin
campaign: The Slip
description: Shady individual with ties to underworld
race:
  - Gnome
gender: Male
class:
---
Race: Gnome
Location: [[Arcabourne]]

Shady individual who had information regarding the archeologists guild and how to access the sealed underground levels. Provided the party with the following note:

![[heist_information.webp]]