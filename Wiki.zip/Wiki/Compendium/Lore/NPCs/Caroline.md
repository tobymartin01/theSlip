---
type: NPC
faction: Archeologist Guild
location: Arcabourne
world: Vardin
campaign: The Slip
description: Leader of Paryty fronting the Archeologist Guild
race:
  - Human
gender: Female
class: Unknown
---
