---
type: NPC
faction: The Argyles
location: Arcabourne
world: Vardin
campaign: The Slip
description: Guild Admin/Quatermaster
race:
  - Human
gender: Male
class:
---
- Has a wife and two kids
- Lost his arm in a dweller attack, a group of weepers
