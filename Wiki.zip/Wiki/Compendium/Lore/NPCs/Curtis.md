---
type: NPC
faction: 
location: Arcabourne
world: Vardin
campaign: The Slip
description: Herbalist and owner of Apothecary
race:
  - Gnome
gender: Male
class:
---
Race: Gnome
Location: [[Arcabourne]]

Gnome herbalist, owner of the Apothecary. Informed me about the herb Auban which can help alleviate symptoms of the slip corruption but cannot cure it