---
type: NPC
faction: 
location: Tibber's Pocket
world: Vardin
campaign: The Slip
description: Pet rock carried around by Tibber
race:
  - Rock
gender: Unknown
class: Unknown
---
