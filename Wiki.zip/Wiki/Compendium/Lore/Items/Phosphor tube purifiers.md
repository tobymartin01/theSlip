---
type: Item
world: Vardin
campaign: The Slip
description: Explosive vile used for purifying corrupted areas
---
