---
type: POI
faction:
location: Arcabourne
world: Vardin
campaign: The Slip
description: Manor of the rich Vayron trading family
---
