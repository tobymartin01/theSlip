---
type: POI
faction: 
location: Arcabourne
world: Vardin
campaign: The Slip
description: The Argyle Guild Hall, originally taken to discuss what happened during the prison break
---
