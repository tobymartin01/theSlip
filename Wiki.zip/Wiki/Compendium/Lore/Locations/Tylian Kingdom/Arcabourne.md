---
type: city
location: Tylian Kingdom
---
