---
type: kingdom
---

**Capital:** [[Arcabourne]]

- A small but powerful nation, and birthplace of the Argyles. Its army is large, professional, and well-equipped, keeping both the Florian Commonwealth and the Khanate at bay.
- Their most powerful regiments of riflemen use 'Synthesis' to create powerful long-range weapons.
- The **Triple Alliance** (Tylia, Aplaria, and Sceca) exists mainly to counter the threat of the Commonwealth, though the nations distrust each other.
- The economy is transitioning from agrarian to industrial due to Synthesis, shifting power from the nobility to oligarchs and merchants.
- Despite the current king's efforts to maintain stability, a brewing power struggle looms on the horizon.