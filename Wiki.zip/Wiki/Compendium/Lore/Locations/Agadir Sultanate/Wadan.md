---
type: city
location: Agadir Sultanate
---
