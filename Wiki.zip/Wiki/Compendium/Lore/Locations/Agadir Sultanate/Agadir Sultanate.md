---
type: kingdom
---

**Capital:** [[Wadan]]

- Shares history and culture with the Ospesh, having migrated across the **Vestia Sea** centuries ago.
- **Religious nation**, rejecting Synthesis as an affront to their gods, leading to **isolationist policies**.
- Economy has **collapsed** due to cutting off trade, leaving **rotting agricultural goods** with no buyers.