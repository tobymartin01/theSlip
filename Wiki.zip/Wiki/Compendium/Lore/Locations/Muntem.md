---
type: city
location: Iron Hills
---

A predominantly Gnomish city at the tip of one of the Iron Hill's peninsulas. It is the only one of its kind, and is home to other smaller groups of species within its limits. They barter and trade with the Dwarves - such as food stuffs and leather works - which are rare among their folk. In return the Dwarves offer their protection of their short kin, and tools and other such metal works. 