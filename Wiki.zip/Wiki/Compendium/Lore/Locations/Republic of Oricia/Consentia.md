---
type: city
location: Republic of Oricia
---
