---
type: kingdom
---

**Capital:** [[Consentia]]

- A **largely peaceful** trading nation with strong relations with most others.
- Hosts one of the **strongest economies**, fueled by vast trade fleets and deep investments into **Synthesis technology**.
- Recently invented **airships**, further strengthening their economic influence.