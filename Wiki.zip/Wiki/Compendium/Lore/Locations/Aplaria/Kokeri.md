---
type: city
location: Aplaria
---
