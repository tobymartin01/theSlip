---
type: kingdom
---

**Capital:** [[Kokeri]]

- A relatively young nation, originally a loose coalition of **tribal raiders**. Only after facing an external invasion did they unify into a central government.
- Economy is the weakest among the **Triple Alliance**, relying on **mining, logging, and fishing**.
- Possesses **the strongest navy**, specializing in fast and powerful strikes.
- Army is centered around a **core of elite infantry**.