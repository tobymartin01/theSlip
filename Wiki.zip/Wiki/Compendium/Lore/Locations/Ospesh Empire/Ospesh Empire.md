---
type: kingdom
---

**Capital:** [[Alistan]]

- An **oriental nation** with an economy based on **spice trade and glass production**.
- Limited population due to **harsh desert conditions**, making it one of the **smallest militaries** in the region.
- Cities are built around **oases and underground water reserves**, which are held as **sacred**.