---
type: city
location: Ospesh Empire
---
