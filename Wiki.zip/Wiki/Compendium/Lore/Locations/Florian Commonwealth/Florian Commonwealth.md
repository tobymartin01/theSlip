---
type: kingdom
---

**Capital:** [[Varadinium]]

- A **highly militarized** nation focused on conquest, closely watching the continent while being kept at bay by the **Triple Alliance**.
- The **oldest Republic in the known world**, governing for nearly 3,000 years through a 100-member body, led by two elected officials who serve a **single six-year term**.
- Leadership positions are often held by **military generals**, reflecting the nation’s militarized culture.