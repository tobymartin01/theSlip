---
type: kingdom
---

**Capital:** [[Nonowon]]

- A **nomadic nation** of tribal horsemen roaming the **Ogemer plains** (Nogoon Tengis).
- Very few cities exist, only **three main settlements**, including the capital Nonowon.
- Economy revolves around **raiding**, though recent years have seen these kept in check by **forts along their borders**.