---
type: city
location: Whuaz Khanate
---
