---
type: kingdom
---

**Capital:** [[Stormfall]]

- Military is small but revolves around **heavy cavalry**.
- **Matriarchal leadership** creates tensions within the Triple Alliance.
- The economy is **in decline** due to stagnation and corruption, with leaders focused on personal wealth.
- Nationalist sentiment is rising, and brutal suppression of revolts has only **exacerbated unrest**.