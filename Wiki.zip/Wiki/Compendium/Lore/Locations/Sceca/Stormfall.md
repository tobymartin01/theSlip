---
type: city
location: Sceca
---
