---
banner: "[[grung.jpeg]]"
banner-x: 47
banner-y: 14
banner-height: 450
type: player
status: alive
---
# *Backstory*
In the dense, mist-veiled jungles beyond the edge of civilization lies **Tribe Xalaki** — my tribe. A proud enclave of Grung, hidden high in the canopy, shrouded by illusion and secrecy. For generations, we lived apart, watching the dryskins from afar, guarding the balance of our jungle home with unwavering suspicion.

But that balance began to crack. The invaders came — **loggers**, **missionaries**, **treasure-seekers** — tearing paths through the undergrowth, bringing noise, smoke, and steel. So the elders acted. They trained a handful of us to go out into the world — spies, shadows, weapons in disguise.

I was one of them.

I became **Obu, the merchant**. I wore silks and smiles, sold jungle wares and whispered stories, brewed “authentic” tonics for coughs I never had. Beneath it all, I watched. I learned. I mapped their supply lines, counted guards, and sent messages home hidden in code — or tucked under the tongues of trained frogs.

But then… something shifted.

Maybe a rival saw through me. Maybe a noble recognized a glyph I forgot to hide. Or maybe it was me — maybe I flinched. The elders told me to poison an aqueduct, and I waited. I told myself it was for strategy, for timing. But the truth? The truth is I didn’t want to see that village suffer.

Because somewhere along the way, the **merchant** had become real. The smiles weren’t always lies. The laughter in the marketplace — I liked it. I felt seen in a way I never had, even in the jungle.

When the elders found out, they did not kill me. **They exiled me.** To a Grung, exile is worse than death. No voice in the chorus. No scent in the water. Just... silence.

So now I walk alone.

But not without purpose. I study the way of the monk, not just to sharpen my body, but to master the **poison within** — the instinct to obey, the need to hide, the urge to lash out. I still strike fast, and I still hit hard — but now I ask why. Now, I look for balance. Between jungle and city. Between Grung and dryskin. Between the mask and the truth.

I am Obu — the exile, the merchant, the monk. And this is not the end of my story. It is only the beginning.
# *Stats*
---
### **Name:** Obu

### **Race:** Grung

### **Class:** Monk 

### **Background:** Failed Merchant 

### **Alignment:** Neutral Good
---
### **Health:** 2/30 

### **Speed:** 35(unarmoured)/25(armoured)

### **AC:** 16

### **Initiative:** +4

### **Passive Perception:** 14

### **Hit Dice:** 3/3 (d8+2)

### **Proficiency Bonus:** +2

### **Darkvision:** 60ft

### **Stats**

| Stat         | Value | Modifier |
| ------------ | ----- | -------- |
| Strength     | 8     | -1       |
| Dexterity    | 18    | +4       |
| Constitution | 16    | +3       |
| Intelligence | 8     | -1       |
| Wisdom       | 14    | +2       |
| Charisma     | 10    | 0        |

### **Saving Throws**

| Stat         | Proficiency (+2) | Modifier |
| ------------ | ---------------- | -------- |
| Strength     | Yes              | +1       |
| Dexterity    | Yes              | +6       |
| Constitution | No               | +2       |
| Intelligence | No               | -1       |
| Wisdom       | No               | +1       |
| Charisma     | No               | -1       |
### **Skills**

| Skill           | Ability      | Proficiency (+2) | Modifier |
| --------------- | ------------ | ---------------- | -------- |
| Acrobatics      | Dexterity    | Yes              | +6       |
| Animal Handling | Wisdom       | No               | +2       |
| Arcana          | Intelligence | No               | -1       |
| Athletics       | Strength     | No               | -1       |
| Deception       | Charisma     | Yes              | 0        |
| History         | Intelligence | No               | -1       |
| Insight         | Wisdom       | Yes              | +2       |
| Intimidation    | Charisma     | No               | 0        |
| Investigation   | Intelligence | No               | +1       |
| Medicine        | Wisdom       | Yes              | +2       |
| Nature          | Intelligence | No               | -1       |
| Perception      | Wisdom       | Yes              | +4       |
| Performance     | Charisma     | No               | -1       |
| Persuasion      | Charisma     | No               | +2       |
| Religion        | Intelligence | Yes              | -1       |
| Sleight of Hand | Dexterity    | No               | +4       |
| Stealth         | Dexterity    | Yes              | +6       |
| Survival        | Wisdom       | No               | +2       |


### **Attacks**

| Ability        | Attack (+Bonus)      | Damage (+Bonus) |
| -------------- | -------------------- | --------------- |
| Unarmed Strike | 1d20+6 (+Prof, +Dex) | 1d4+4 (+Dex)    |
|                |                      |                 |

### **Abilities** [0/2 Ki]

| Ability             | Type                 | Cost     | Desc                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| ------------------- | -------------------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Flurry of Blows     | Bonus Action         | 1 Ki     | After you take Attack action, spend 1 ki to make 2 unarmed strikes.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| Martial Arts        | Bonus Action         | -        | Make an extra unarmed strike when you take Attack action.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Patient Defense     | Bonus Action         | 1 Ki     | Spend 1 ki point to take the Dodge action.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Step of the Wind    | Bonus Action         | 1 Ki     | Spend 1 ki point to take the Disengage or Dash action and jump distance is doubled for the turn.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| Poisonous Skin      | Passive/Bonus Action | 2/2 (SR) | Any creature that grapples you or otherwise comes into direct contact with your skin must succeed on a DC 12 Constitution saving throw or become poisoned for 1 minute. A poisoned creature no longer in direct contact with you can repeat the saving throw at the end of each of its turns, ending the effect on itself on a success. You can also apply this poison to any piercing weapon as part of an attack with that weapon, though when you hit the poison reacts differently. The target must succeed on a DC 12 Constitution saving throw or take 2d4 poison damage. |
| Standing Leap       | Movement             | -        | Your long jump is up to 25 feet and your high jump is up to 15 feet, with or without a running start.                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| Supply Chain        | Out of Combat        | -        | From your time as a merchant, you retain connections with wholesalers, suppliers, and other merchants and entrepreneurs. You can call upon these connections when looking for items or information.                                                                                                                                                                                                                                                                                                                                                                             |
| Water Dependancy    | Passive              | -        | If you fail to immerse yourself in water for at least 1 hour during a day, you suffer one level of exhaustion at the end of that day. You an only recover from this exhaustion through magic or by immersing yourself in water for at least 1 hour.                                                                                                                                                                                                                                                                                                                             |
| Deflect Missiles    | Reaction             | -        | When hit by a ranged attack, reduce the damage by 1d10 +6. <br>If you reduce it to 0, you can catch the missile (if you have a free hand and it's<br>small enough to hold) and use it in a ranged attack with proficiency, as a monk weapon, for 1 ki point with range 20/60.                                                                                                                                                                                                                                                                                                   |
| Open Hand Technique | Passive              | -        | When you hit with Flurry of Blows, you impose one of the effects on the target: 1) must make a DC 11 DEX save or be knocked prone. <br>2) make a DC 11 STR save or be pushed 15 ft. <br>3) can't take reactions until end of your next turn.                                                                                                                                                                                                                                                                                                                                    |
|                     |                      |          |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |

### **Money**

| Form         | Amount |
| ------------ | ------ |
| Gold Piece   | 2      |
| Silver Piece | 24     |
| Copper Piece | 56     |

### **Items**

| Item                  | Amount | Details            |
| --------------------- | ------ | ------------------ |
| Pouch                 | 1      | 5 sp, 1 lb.        |
| Cartographer's Tools  | 1      |                    |
| Waterskin             | 1      | 2 sp, 5 lb. (full) |
| Bedroll               | 1      | 1 gp, 7 lb.        |
| Rations (1 day)       | 10     | 5 sp, 2 lb.        |
| Rope, hempen          | 1      | 1 gp, 10 lb.       |
| Scale, merchant’s     | 1      | 5 gp, 3 lb.        |
| Tinderbox             | 1      | 5 sp, 1 lb.        |
| Mess kit              | 1      | 2 sp, 1 lb.        |
| Backpack              | 1      | 2 gp, 5 lb.        |
| Clothes, fine         | 1      | 15 gp, 6 lb.       |
| Torch                 | 10     | 1 cp, 1 lb.        |
| Poison Vial (2 uses)  | 1      |                    |
| Florian Broach        | 1      |                    |
| Note with Broken Seal | 1      |                    |

# _Note:

Fists are finess, could multi-class rogue
# *Future Development:*
## **Full Monk**
If you're focusing on **unarmed combat power** (damage, control, survivability), here's a breakdown of the **strongest monk paths** and **multi-class options** from level 3 onward, ranked and analyzed based on **raw effectiveness, synergy with Monk features, and sustained combat viability**:

---

### 🥇 **Way of the Open Hand** (Top Pick for Pure Unamed Power)

**Strengths**:

- **Flurry of Blows = battlefield control**: Push, knock prone, or deny reactions — every turn.
    
- **Full Monk feature synergy** — no clunky extras, just unarmed strike dominance.
    
- **Reliable damage scaling** with martial arts dice, no need for multiclassing tricks.
    

**Key Abilities**:

- **Open Hand Technique (Lvl 3)**: Each Flurry of Blows attack can:
    
    - Knock prone (advantage on follow-ups!)
        
    - Push 15 ft (shove off ledges!)
        
    - Deny reactions (safe disengage)
        
- **Wholeness of Body (Lvl 6)**: Self-heal = better sustain
    
- **Quivering Palm (Lvl 17)**: Literal death touch (save or drop to 0 HP)
    

**Best for**: Staying 100% Monk and dominating unarmed combat cleanly. This is your best option if you want to remain thematic and deadly in close combat.

---

### 🥈 **Way of the Shadow** (Best for Mobility + Stealth)

**Why it's strong**:

- **Shadow Step (Lvl 6)**: Teleport as a bonus action between dim light — with **advantage** on next melee attack.
    
- With unarmed strikes and stunning strike, you can play like a ninja: teleport in, punch them senseless, vanish.
    

Less damage-focused than Open Hand, but **incredible mobility and advantage generation**.

---

### 🥉 **Multiclass: Monk + Rogue (Thief or Assassin)**

### Monk 5 / Rogue X (Thief preferred)

**Why it's strong**:

- You make **multiple unarmed attacks per round** as a Monk...
    
- With **Sneak Attack** added once per turn if you hit with finesse weapon (yes, **unarmed strikes can count** if your DM allows them to be finesse — RAW they don’t, but many DMs homebrew that they do due to Monk mechanics).
    

✅ **Bonus Actions** from Monk + **Cunning Action** from Rogue = super mobile.  
✅ Thief’s **Fast Hands** (Lvl 3) lets you interact with items — heal, throw, grapple, etc.

> ⚠️ Sneak Attack usually requires a finesse or ranged weapon, and unarmed strikes **aren’t weapons** RAW — so this build depends on DM approval or homebrew.

---

### 🥋 **Multiclass: Monk + Barbarian (for MAD builds with armorless defense)**

**Monk 5 / Barbarian 2–3**

- **Rage**: Bonus damage to melee attacks, resistance to physical damage
    
- **Unarmored Defense** (Dex + Con) stacks differently than Monk's AC (Dex + Wis) — your DM will make you choose one, but still synergizes well.
    
- Your unarmed strikes benefit from **Rage** since they are **melee strength-based**, but...
    
    - If you're using **Dex-based attacks** (most Monks do), you may not benefit from Rage unless you switch to **Strength Monk** (rare but viable with rolled stats or point buy).
        

> ✅ Tankier monk  
> ❌ Conflicting stat needs (Str vs Dex/Wis)

---

### 🔥 _Other strong Monk options_

### **Way of Mercy** – Best for versatility

- Can **heal and harm** with unarmed strikes (via Ki)
    
- Adds **necrotic damage** on hits
    
- Use **Flurry of Blows** for healing _or_ hurting — extremely flexible in group play
    

---

### 💡 Recommended Build for Obu (Optimized Unarmed Striker)

**Pure Monk (Way of the Open Hand)**

- Simple, thematic, brutally effective
    
- Use Stunning Strike + Flurry + Open Hand Technique for constant control
    

**OR**

**Monk 6 / Rogue 3 / Fighter 2 (Battle Master)**

- Open with **Martial Arts** + **Sneak Attack**
    
- Use **Battle Master maneuvers** with unarmed strikes (with DM approval)
    
- Combine Monk’s mobility with **Rogue cunning** and Fighter versatility
    

---

### Summary

|Build|Style|Damage|Control|Complexity|
|---|---|---|---|---|
|**Way of the Open Hand**|Pure unarmed power|⭐⭐⭐⭐|⭐⭐⭐⭐|🟢 Simple|
|Way of Shadow|Ninja teleport striker|⭐⭐⭐|⭐⭐⭐⭐|🟡 Moderate|
|Monk + Rogue (Thief)|Slippery striker|⭐⭐⭐⭐|⭐⭐|🔴 Complex|
|Monk + Barbarian|Tanky brawler|⭐⭐|⭐⭐|🟠 Tough to build|
|Way of Mercy|Versatile striker/support|⭐⭐⭐|⭐⭐|🟡 Moderate|

---

Would you like me to help plan a full build for Obu from levels 1–10, including stats and feat choices?

## **Monk/Rogue**

Absolutely! Let’s build **Obu the Grung Monk** with a **Rogue multiclass** — optimized for unarmed combat, mobility, and stealthy subterfuge — perfect for an exiled jungle spy with a shadowy past.

---

### 🐸 Obu, Grung Monk/Rogue (Levels 1–10)

- **Race**: Grung (+2 DEX, +1 CON)
    
- **Starting Class**: Monk (better saves and early unarmed power)
    
- **Primary Stats**: DEX > WIS > CON
    
- **Playstyle**: Sneaky striker, ambusher, controller — flexible and fast
    

---

### 🎲 Ability Scores (Post-Racial, Point Buy or Standard Array)

|Stat|Score|Notes|
|---|---|---|
|**DEX**|16+2 = 18|Attack, AC, Sneak Attack, initiative|
|**WIS**|14|Monk features, AC|
|**CON**|13+1 = 14|HP|
|**STR**|8|Dump stat|
|**INT**|8|Dump stat|
|**CHA**|10|Slight charm for RP|

> You’ll use DEX for attacks, Monk AC, Stealth, and Sneak Attack.

---

### 🧭 Class Split Recommendation

- **Monk 6 / Rogue 4** — strong synergy, control + sneak damage + mobility
    
- Could flip to **Monk 5 / Rogue 5** for more utility & Cunning Action
    

---

### 📈 Level-by-Level Breakdown

#### 🥋 Level 1 – **Monk 1**

- Martial Arts (1d4), Unarmored Defense (AC = DEX + WIS)
    
- Strong start: Bonus unarmed strikes, good AC
    
- **Start as Monk** for Dexterity and Wisdom saves
    

---

#### 🐾 Level 2 – **Monk 2**

- **Ki** (Flurry of Blows, Step of the Wind, Patient Defense)
    
- +10 ft movement
    

---

#### 👊 Level 3 – **Monk 3 (Way of Shadow or Open Hand)**

- **Way of the Shadow** (RP fit for stealthy spy monk):
    
    - Minor Illusion, Darkness, Pass Without Trace (great utility)
        
- **OR Way of the Open Hand** (better in melee):
    
    - Prone / Push / Reaction denial with Flurry of Blows
        

➡️ _Both are strong — pick based on whether you want stealth caster (Shadow) or better battlefield control (Open Hand)_

---

#### ⚔️ Level 4 – **Monk 4**

- **Feat or ASI**: Take **Mobile**
    
    - +10 ft speed
        
    - No opportunity attacks from creatures you attack
        
    - Great synergy with both Rogue & Monk hit-and-run tactics
        

---

#### 🧤 Level 5 – **Monk 5**

- **Extra Attack**
    
- **Stunning Strike**
    
- Martial Arts die: 1d6
    

✅ _Peak monk power here — multiple attacks + stun_

---

#### 🌑 Level 6 – **Monk 6**

- **Ki-Empowered Strikes** (unarmed = magical)
    
- **Way of Shadow**: Darkness/PWOT on short rest  
    or  
    **Open Hand**: Wholeness of Body healing
    

🛑 You could stop Monk here. Next levels go Rogue.

---

#### 🗡️ Level 7 – **Rogue 1**

- **Sneak Attack** (1d6)
    
- **Expertise** (Stealth, Acrobatics or Deception)
    
- **Thieves’ Cant**
    

➡️ _Unarmed strikes = finesse weapons (RAW/RAI), so you qualify for Sneak Attack when the conditions are met!_

---

#### 🧍‍♂️ Level 8 – **Rogue 2**

- **Cunning Action**: Bonus action Dash, Hide, Disengage
    
- Now you can Flurry of Blows _or_ Cunning Action as needed
    

✅ Ultimate mobility. You are the jungle shadow.

---

#### 🧠 Level 9 – **Rogue 3 (Subclass)**

- **Subclass Choice**: Two strong options:
    

##### 🕶️ Soulknife _(Psychic blades + utility)_

- Sneak Attack = psychic blades
    
- Telepathic communication
    
- Psi-Bolstered Knack (boost skills like Stealth)
    

##### 🩸 Assassin _(Striker with disguise flavor)_

- Auto-crit surprise turns (great with Monk’s many attacks)
    
- Proficiency in Disguise Kit, Poisoner’s Kit (perfect RP fit)
    

✅ _Soulknife = utility/stealth. Assassin = burst damage / spy theme._

---

#### 🎯 Level 10 – **Rogue 4**

- **ASI / Feat**:
    
    - **+2 DEX** (reach 20)
        
    - or **Alert** for +5 initiative (nasty with Stunning Strike)
        
    - or **Lucky**
        

---

### 🥋 Combat Style

- **Attack Action**: 2 unarmed strikes (Monk 5)
    
- **Bonus Action**:
    
    - Martial Arts (3rd attack)
        
    - Flurry of Blows (4th attack, with ki)
        
    - Sneak Attack once per turn (if engaged with ally or you have advantage)
        
- **Grung Poison**: Use once per short rest (can stack with Sneak Attack + Stunning Strike for brutal openers)
    

---

### 🧳 Tools & Skills

- Expertise in **Stealth** and **Deception/Acrobatics**
    
- Proficient with **Disguise Kit**, **Thieves’ Tools**, **Forgery Kit** (from background or subclass)
    
- Monk speed + Cunning Action = superior infiltration
    

---

### Summary: Obu the Grung Monk/Rogue

|Level|Monk|Rogue|Key Power Spike|
|---|---|---|---|
|1|1|0|Martial Arts, AC|
|3|3|0|Shadow/Open Hand unlocked|
|5|5|0|Extra Attack, Stunning Strike|
|6|6|0|Magic strikes, subclass power|
|7|6|1|Sneak Attack, Expertise|
|9|6|3|Subclass (Assassin or Soulknife)|
|10|6|4|DEX 20 or Alert feat|

---

Would you like this turned into a digital or printable character sheet as well? Or a comparison between the **Open Hand Monk** vs **Shadow Monk** routes with Rogue?