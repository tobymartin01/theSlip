---
banner: "![[Compendium/Resources/Maps/blank_world_map.png]]"
type: overview
campaign: The Slip
---
# Sessions
```dataview 
table date as Date, location as Location
FROM -"Templates"
WHERE contains(type, "session")
SORT file.name DESC
```
# Players
```dataview 
table status as Status
WHERE contains(type, "player")
SORT status ASC, file.name ASC
```
# Kingdoms
```dataview 
table
WHERE contains(type, "kingdom")
SORT file.name ASC
```
# Cities
```dataview 
table location as Location
WHERE contains(type, "city")
SORT file.name ASC
```
# Groups
```dataview 
table type as Type
WHERE contains(type, "faction")
SORT file.name ASC
```

# NPCs
```dataview 
table location as Location, description as Description
FROM -"Templates"
WHERE contains(type, "NPC")
SORT file.name ASC
```

# Monsters
```dataview 
table race as Race, description as Description
FROM -"Templates"
WHERE contains(type, "Monster")
SORT race ASC
```
